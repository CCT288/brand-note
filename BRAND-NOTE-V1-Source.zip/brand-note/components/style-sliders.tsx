"use client";
import { styleLabels } from "@/lib/domain";
export function StyleSliders({value,onChange}:{value:number[];onChange:(value:number[])=>void}) {
  return <div className="grid gap-x-8 gap-y-5 sm:grid-cols-2">{styleLabels.map((name,i)=><label key={name} className="block text-xs"><span className="mb-3 flex justify-between">{name}<span className="tabular-nums text-muted-foreground">{value[i]}</span></span><input type="range" aria-label={name} min="0" max="100" value={value[i]} className="block w-full accent-[#42493d]" onChange={event=>onChange(value.map((n,index)=>index===i ? Number(event.target.value):n))}/></label>)}</div>;
}
