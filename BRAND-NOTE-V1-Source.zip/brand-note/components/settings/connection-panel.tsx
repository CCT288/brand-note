"use client";
import { useEffect, useState } from "react";
import { Check, ArrowUpRight, Loader2, Circle, ImagePlus } from "lucide-react";
import { Button } from "@/components/ui/button";

type Report = { checkedAt: string; model: string; text: boolean; structured: boolean; image: boolean; sample: string };
type Session = { connected: boolean; planEnabled: boolean; email: string | null; reauthRequired: boolean; verification: Report | null };
type Model = { slug: string; display_name: string };
async function getJson(url: string, options?: RequestInit) {
  const response = await fetch(url, { ...options, cache: "no-store" });
  const value = await response.json();
  if (!response.ok) throw new Error(`${value.error ?? "请求未完成"} (${value.code ?? response.status})`);
  return value;
}
export function ConnectionPanel() {
  const [session, setSession] = useState<Session | null>(null);
  const [models, setModels] = useState<Model[]>([]);
  const [model, setModel] = useState("");
  const [image, setImage] = useState<string>();
  const [imageName, setImageName] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [preferences,setPreferences] = useState({text_model:"gpt-6.1-sol",vision_model:"gpt-6.1-sol"});
  const [database,setDatabase] = useState(false);
  const [deployment,setDeployment] = useState("local");
  useEffect(() => {
    let active = true;
    getJson("/api/chatgpt/session").then(value => {
      if (!active) return;
      setSession(value);
      const query = new URLSearchParams(window.location.search);
      if (query.get("connection") === "failed") setError(`官方授权未完成 (${query.get("code") ?? "unknown"})。请重新连接，旧记录已保留。`);
      if (query.get("connection") === "success") setNotice(value.planEnabled ? "账号已连接。请选择模型并验证真实生成。" : "账号已登录，但还没有计划使用权限。请在 ChatGPT 中检查授权。");
      if (query.has("connection")) window.history.replaceState(null, "", "/settings");
    }).catch(reason => { if (active) setError(reason.message); });
    getJson("/api/preferences").then(value=>{if(active){setPreferences(value.settings);setDatabase(value.database);setDeployment(value.deployment);}}).catch(reason=>{if(active)setError(reason.message);});
    return () => { active = false; };
  }, []);
  async function loadModels() {
    setBusy("models"); setError(""); setNotice("");
    try { const data = await getJson("/api/chatgpt/models"); setModels(data.models); setModel(data.models[0]?.slug ?? ""); if (!data.models.length) setError("此账号没有返回可显示的模型。请检查计划使用权限。"); }
    catch (reason) { setError((reason as Error).message); }
    finally { setBusy(null); }
  }
  async function verify() {
    setBusy("verify"); setError(""); setNotice("");
    try {
      const report = await getJson("/api/chatgpt/verify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model, image }) });
      setSession(current => current ? { ...current, verification: report } : current);
      setNotice(image ? "中文、结构化输出及图片观察验证通过。" : "中文和结构化输出验证通过。添加测试图片后可验证图片输入。");
    } catch (reason) { setError((reason as Error).message); }
    finally { setBusy(null); }
  }
  async function disconnect() {
    if (!window.confirm("断开 BRAND NOTE 的 ChatGPT 连接？不会删除你的品牌资料。")) return;
    setBusy("disconnect"); setError("");
    try {
      const result = await getJson("/api/chatgpt/disconnect", { method: "POST" });
      setSession({ connected: false, planEnabled: false, email: null, reauthRequired: false, verification: null }); setModels([]); setModel("");
      setNotice(result.revoked ? "已断开连接。" : "此工作台的连接已清除，但远程撤销未确认。请在 ChatGPT 设置 中断开此应用。");
    } catch (reason) { setError((reason as Error).message); }
    finally { setBusy(null); }
  }
  async function saveModels(){setBusy("settings");setError("");try{await getJson("/api/preferences",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(preferences)});setNotice("文本与图片模型已保存。");}catch(reason){setError((reason as Error).message);}finally{setBusy(null);}}
  const report = session?.verification;
  return <div className="mt-10">
    <section className="border-y py-6">
      <div className="flex flex-wrap items-start justify-between gap-5"><div><h2 className="text-sm font-medium">ChatGPT 连接</h2><p className="mt-2 text-xs text-muted-foreground">使用你已订阅的 Plus 计划，先完成官方授权。</p></div><span className="inline-flex items-center gap-2 text-xs text-muted-foreground"><Circle size={7} fill={session?.planEnabled ? "#667c55" : "#a4a59e"} stroke="none"/>{session?.planEnabled ? "已授权使用 Plus" : session?.connected ? "待授权 Plus 额度" : "未连接"}</span></div>
      {session?.email && <p className="mt-5 text-xs">{session.email}</p>}
      <div className="mt-5 flex flex-wrap items-center gap-4">{deployment==="local"?<form action="/api/chatgpt/connect" method="POST"><Button type="submit" disabled={!!busy}>{session?.connected ? "重新连接 ChatGPT" : "连接 ChatGPT"}</Button></form>:<p className="text-xs text-muted-foreground">连接授权在你的 Mac 完成，再安全同步到线上。</p>}<a href="https://chatgpt.com/settings/usage" target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">查看使用额度<ArrowUpRight size={12}/></a>{session?.connected && <button type="button" onClick={disconnect} disabled={!!busy} className="text-xs text-muted-foreground underline underline-offset-4">断开连接</button>}</div>
      <p className="mt-4 max-w-xl text-[11px] leading-6 text-muted-foreground">你会进入 OpenAI 官方页面。请允许使用 ChatGPT 计划，并保持额外付费额度关闭。此应用不会自动切换到付费 API。</p>
    </section>
    {session?.planEnabled && <section className="border-b py-7"><div className="flex items-center justify-between gap-4"><h2 className="text-sm font-medium">模型与连接测试</h2><Button variant="outline" size="sm" onClick={loadModels} disabled={!!busy}>{busy === "models" && <Loader2 size={14} className="animate-spin"/>}获取可用模型</Button></div><p className="mt-2 text-xs text-muted-foreground">仅显示你的账号实际提供的模型。</p>{models.length > 0 && <div className="mt-5 space-y-5"><div><label htmlFor="model" className="mb-2 block text-xs">测试模型</label><select id="model" value={model} onChange={event => setModel(event.target.value)} disabled={!!busy} className="w-full rounded-md border bg-white px-3 py-2.5 text-sm sm:max-w-sm">{models.map(option => <option key={option.slug} value={option.slug}>{option.display_name}</option>)}</select></div><div><label htmlFor="test-image" className="inline-flex cursor-pointer items-center gap-2 text-xs text-muted-foreground"><ImagePlus size={15}/> {imageName || "选择测试图片（可选）"}</label><input id="test-image" type="file" accept="image/png,image/jpeg,image/webp" disabled={!!busy} className="mt-2 block w-full text-xs file:mr-3 file:rounded-md file:border file:bg-white file:px-3 file:py-2" onChange={event => {
        const file = event.target.files?.[0]; setImage(undefined); setImageName("");
        if (!file) return;
        if (file.size > 5_000_000) { setError("测试图片请小于 5 MB。"); return; }
        if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) { setError("请选择 PNG、JPEG 或 WebP 图片。"); return; }
        const reader = new FileReader(); reader.onload = () => { setImage(String(reader.result)); setImageName(file.name); setError(""); }; reader.onerror = () => setError("图片读取失败，请重试。"); reader.readAsDataURL(file);
      }}/></div><Button onClick={verify} disabled={!!busy || !model}>{busy === "verify" && <Loader2 size={14} className="animate-spin"/>}{busy === "verify" ? "测试中…" : "测试真实生成"}</Button><p className="text-[11px] text-muted-foreground">此测试会使用少量已授权的订阅额度。测试图片不会保存到资料库。</p></div>}</section>}
    {report && <section className="border-b py-7"><h2 className="text-sm font-medium">测试结果</h2><div className="mt-4 flex flex-wrap gap-x-6 gap-y-3">{[{ label: "中文", ok: report.text },{ label: "结构化输出", ok: report.structured },{ label: "图片输入", ok: report.image }].map(item => <span key={item.label} className="inline-flex items-center gap-2 text-xs">{item.ok ? <Check size={14} className="text-[#667c55]"/> : <Circle size={12} className="text-muted-foreground"/>}{item.label}<span className="text-muted-foreground">{item.ok ? "通过" : "未验证"}</span></span>)}</div><p className="mt-5 rounded-md bg-muted px-4 py-3 text-sm leading-6">{report.sample}</p><p className="mt-3 text-[11px] text-muted-foreground">{report.model} · {new Date(report.checkedAt).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" })} · {deployment==="cloud"?"线上验证":"本机验证"}</p></section>}
    {error && <p role="alert" className="mt-5 rounded-md border border-[#d7b5ae] bg-[#fcf7f5] px-4 py-3 text-xs leading-6 text-[#80584f]">{error}</p>}
    {notice && <p role="status" className="mt-5 text-xs leading-6 text-[#5f7054]">{notice}</p>}
    {!!models.length&&<section className="border-b py-7"><h2 className="text-sm font-medium">生成设置</h2><div className="mt-5 grid gap-4 sm:grid-cols-2">{([{key:"text_model",label:"文字模型"},{key:"vision_model",label:"图片模型"}] as const).map(f=><label key={f.key} className="text-xs">{f.label}<select className="mt-2 w-full rounded-md border px-3 py-2.5 text-sm" value={preferences[f.key]} onChange={e=>setPreferences(current=>({...current,[f.key]:e.target.value}))}>{models.map(m=><option key={m.slug} value={m.slug}>{m.display_name}</option>)}</select></label>)}</div><Button variant="outline" size="sm" className="mt-4" onClick={saveModels} disabled={!!busy}>保存模型设置</Button></section>}
    <section className="border-b py-7"><h2 className="text-sm font-medium">云端资料库</h2><p className="mt-2 text-xs text-muted-foreground">{database?"云端资料库已连接 · 素材私有保存":"仅保存在本机 · 云端未连接"}</p><p className="mt-4 text-xs leading-6 text-muted-foreground">{database?"品牌、素材和历史通过指定账号访问。":"当前资料保存在这台 Mac；手机同步仍需完成线上配置。"}</p><Button variant="outline" size="sm" className="mt-4" onClick={async()=>{try{await getJson("/api/workspace",{method:"POST"});setNotice("品牌资料已初始化。请打开品牌页。");}catch(reason){setError((reason as Error).message);}}}>导入已有品牌配置</Button></section>
    <section className="py-7"><h2 className="text-sm font-medium">工作台访问</h2><p className="mt-2 text-xs leading-6 text-muted-foreground">{deployment==="cloud"?"云端工作台 · 仅指定账号可访问。请以验收记录中的实测结果为准。":"本机工作台 · 线上访问尚未交付。"}</p>{deployment==="cloud"&&<form action="/api/logout" method="POST" className="mt-4"><Button variant="outline" size="sm">退出登录</Button></form>}</section>
  </div>;
}
