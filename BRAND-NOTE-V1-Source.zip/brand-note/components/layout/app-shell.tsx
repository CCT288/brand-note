"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { PenLine, Tags, Library, Settings2, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";

const links = [ { href: "/write", name: "写文案", icon: PenLine }, { href: "/brands", name: "品牌", icon: Tags }, { href: "/library", name: "资料库", icon: Library }, { href: "/settings", name: "设置", icon: Settings2 } ];
export function AppShell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  return <div className="min-h-dvh">
    <aside className="fixed inset-y-0 left-0 hidden w-56 flex-col border-r bg-[#fafaf8] px-4 py-7 md:flex">
      <Link href="/write" className="px-3 text-[13px] font-semibold tracking-[0.16em]">BRAND NOTE<span className="ml-2 text-[10px] font-normal tracking-normal text-muted-foreground">V1</span></Link>
      <p className="mb-9 mt-2 px-3 text-[11px] text-muted-foreground">给品牌写合适的发布文案。</p>
      <nav className="space-y-1">{links.map(({ href, name, icon: Icon }) => <Link key={href} href={href} aria-current={path.startsWith(href) ? "page" : undefined} className={cn("flex items-center gap-3 rounded-md px-3 py-2.5 text-[13px] text-muted-foreground transition-colors hover:bg-[#efefec] hover:text-foreground", path.startsWith(href) && "bg-[#ebede7] font-medium text-foreground")}><Icon size={16} strokeWidth={1.6}/>{name}</Link>)}</nav>
      <div className="mt-auto border-t px-3 pt-5"><p className="text-[11px] text-muted-foreground">个人工作台</p><Link href="/settings" className="mt-2 flex items-center justify-between text-xs">连接设置<ArrowUpRight size={13}/></Link></div>
    </aside>
    <header className="flex items-center justify-between border-b px-5 py-4 md:hidden"><Link href="/write" className="text-xs font-semibold tracking-[0.15em]">BRAND NOTE</Link><span className="text-[10px] text-muted-foreground">个人工作台</span></header>
    <div className="md:ml-56"><div className="hidden h-12 items-center justify-between border-b px-10 text-[11px] text-muted-foreground md:flex"><span>工作台 / <span className="text-foreground">{links.find(l => path.startsWith(l.href))?.name}</span></span><span>BRAND NOTE · 个人工作台</span></div><main className="mx-auto max-w-5xl px-5 pb-28 pt-8 sm:px-10 md:pb-16 md:pt-14">{children}</main></div>
    <nav className="fixed inset-x-0 bottom-0 z-20 flex border-t bg-white/95 pb-[env(safe-area-inset-bottom)] md:hidden">{links.map(({ href, name, icon: Icon }) => <Link key={href} href={href} aria-current={path.startsWith(href) ? "page" : undefined} className={cn("flex flex-1 flex-col items-center gap-1 py-3 text-[10px] text-muted-foreground", path.startsWith(href) && "text-foreground")}><Icon size={18}/>{name}</Link>)}</nav>
  </div>;
}
