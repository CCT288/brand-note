import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { z } from "zod";
import { readRecord, writeRecord, withConnectionLock } from "../lib/chatgpt/storage";

test("credentials are owner-only and corrupt records are preserved instead of reset", async () => {
  const temporary = await mkdtemp(join(tmpdir(), "brand-note-test-"));
  const previous = process.env.BRAND_NOTE_RUNTIME_DIR;
  process.env.BRAND_NOTE_RUNTIME_DIR = join(temporary, "private");
  try {
    await writeRecord("test.json", { value: "private-test" });
    assert.equal((await stat(join(temporary, "private"))).mode & 0o777, 0o700);
    assert.equal((await stat(join(temporary, "private", "test.json"))).mode & 0o777, 0o600);
    assert.deepEqual(await readRecord("test.json", z.object({ value: z.string() })), { value: "private-test" });
    await withConnectionLock(async () => {
      await assert.rejects(withConnectionLock(async () => "second"), /连接正在更新/);
    });
    assert.equal(await withConnectionLock(async () => "released"), "released");
    await writeFile(join(temporary, "private", "test.json"), "broken");
    await assert.rejects(readRecord("test.json", z.object({ value: z.string() })), /已保留原文件/);
    assert.equal(await readRecord("absent.json", z.object({ value: z.string() })), null);
  } finally {
    if (previous === undefined) delete process.env.BRAND_NOTE_RUNTIME_DIR; else process.env.BRAND_NOTE_RUNTIME_DIR = previous;
    await rm(temporary, { recursive: true, force: true });
  }
});
