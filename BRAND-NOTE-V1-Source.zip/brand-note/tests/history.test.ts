import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { brandSchema, contentSchema, type Content } from "../lib/domain";
import { recentHistory, historyCheck, learnedMemory } from "../lib/history";
const brand=brandSchema.parse({id:randomUUID(),name:"Fictional studio",english_name:"",category:"",city:"",description:"",keywords:[],default_style_json:[50,50,50,50,50,50],voice:{personality:"",writing_principles:"",avoid_rules:""},facts:[],memory:[],updated_at:new Date().toISOString()});
function item(index:number,patch:Partial<Content>={}):Content {
 const id=randomUUID(),variantId=randomUUID();
 return contentSchema.parse({id,owner_id:"test",brief:{brand_id:brand.id,mode:"Quick",content_type:"人物",raw_input:"Fictional example",style_json:[50,50,50,50,50,50]},brand_snapshot:brand,created_at:new Date(index*1000).toISOString(),updated_at:new Date(index*1000).toISOString(),archived_at:new Date(index*1000).toISOString(),status:"Used",stage:7,stage_results:{},variants:[{id:variantId,direction:{id:"1",label:"人物",angle:"工作片段",reason:"具体",difference:"人物"},title:"原稿标题",copy:"原稿正文"}],revisions:[{id:randomUUID(),variant_id:variantId,kind:"copy",applied:true,preference_key:"natural_copy",created_at:new Date().toISOString()}],selected_variant_id:variantId,ai_title:"原稿标题",ai_copy:"原稿正文",final_title:"今天的具体人物",final_copy:"同一句话出现两次用于检查。",warning:"",error:null,model:"test",vision_model:"test",critic_attempts:0,version:0,...patch});
}
test("history includes only latest 30 archived items from this brand and prefers final edits",()=>{
 const contents=Array.from({length:40},(_,i)=>item(i));contents.push(item(100,{archived_at:null}));const other=item(101);other.brief.brand_id=randomUUID();contents.push(other);
 const selected=recentHistory(contents,brand.id);assert.equal(selected.length,30);assert.equal(selected[0].created_at,contents[39].created_at);assert.ok(selected.every(c=>c.archived_at&&c.brief.brand_id===brand.id));
 const result=historyCheck(selected);assert.equal(result.recent[0].title,selected[0].final_title);assert.ok(result.repeated_openings.includes("今天"));assert.ok(result.repeated_sentences.includes("同一句话出现两次用于检查"));assert.ok(result.warning);
});
test("learning needs three independent archived contents with applied long-term preferences",()=>{
 const first=item(1);first.revisions.push({...first.revisions[0],id:randomUUID()});assert.deepEqual(learnedMemory(brand,[first,item(2)]),[]);
 const unaccepted=item(3);unaccepted.revisions[0].applied=false;assert.deepEqual(learnedMemory(brand,[first,item(2),unaccepted]),[]);
 const transient=item(4);transient.revisions[0].preference_key="one_event";assert.deepEqual(learnedMemory(brand,[first,item(2),transient]),[]);
 const other=item(5);other.brief.brand_id=randomUUID();assert.deepEqual(learnedMemory(brand,[first,item(2),other,item(6,{archived_at:null})]),[]);
 const learned=learnedMemory(brand,[first,item(2),item(3)]);assert.equal(learned[0].source_count,3);assert.equal(new Set(learned[0].source_ids).size,3);assert.equal(learned[0].key,"natural_copy");
});
