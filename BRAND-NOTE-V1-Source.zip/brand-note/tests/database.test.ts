import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { PGlite } from "@electric-sql/pglite";
import { randomUUID } from "node:crypto";

test("migration enforces owner isolation, immutable originals, archive idempotency and service-only locks",async()=>{
  const db=await PGlite.create();
  const owner=randomUUID(),other=randomUUID(),brandId=randomUUID(),contentId=randomUUID(),variantId=randomUUID();
  try{
    await db.exec(`create role anon;create role authenticated;create role service_role bypassrls;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated,service_role;grant execute on function auth.uid() to authenticated,service_role;create schema storage;create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);create table storage.objects(id uuid default gen_random_uuid(),bucket_id text,name text);alter table storage.objects enable row level security;create function storage.foldername(text) returns text[] language sql immutable as $$select string_to_array($1,'/')$$;grant usage on schema storage to authenticated;grant all on storage.objects to authenticated;grant execute on function storage.foldername(text) to authenticated;`);
    await db.exec(await readFile(new URL("../supabase/migrations/20261011034934_brand_note_v1.sql",import.meta.url),"utf8"));
    await db.exec(await readFile(new URL("../supabase/migrations/20261011042000_restrict_auto_rls_trigger.sql",import.meta.url),"utf8"));
    await db.query("insert into auth.users(id) values($1),($2)",[owner,other]);await db.query("insert into private.workspace_owner(user_id) values($1)",[owner]);
    await db.exec("set role authenticated");await db.query("select set_config('request.jwt.claim.sub',$1,false)",[owner]);
    const brand={id:brandId,name:"Example Bar",english_name:"Example Bar",category:"",city:"",description:"",keywords:[],default_style_json:[50,50,50,50,50,50],voice:{personality:"",writing_principles:"",avoid_rules:""},facts:[],memory:[]};
    await db.query("select public.bn_save_brand($1::jsonb)",[JSON.stringify(brand)]);
    const content={id:contentId,owner_id:owner,brief:{brand_id:brandId,mode:"Quick",content_type:"日常",raw_input:"Fictional test",topic:"",message:"",must_include:"",avoid:"",style_json:[50,50,50,50,50,50]},brand_snapshot:brand,stage_results:{},ai_title:"",ai_copy:"",final_title:"",final_copy:"",status:"Used",archived_at:null as string|null,version:0,variants:[{id:variantId,direction:{label:"人物",angle:"观察工作人员"},title:"Original",copy:"Original copy"}],revisions:[]};
    await db.query("select public.bn_save_content($1::jsonb,$2)",[JSON.stringify(content),null]);
    content.version=1;content.ai_title="Original";content.ai_copy="Original copy";content.final_title="Final";content.final_copy="Final copy";content.archived_at=new Date().toISOString();
    await db.query("select public.bn_save_content($1::jsonb,$2)",[JSON.stringify(content),0]);
    content.version=2;await db.query("select public.bn_save_content($1::jsonb,$2)",[JSON.stringify(content),1]);
    assert.equal((await db.query<{n:number}>("select count(*)::int n from public.contents")).rows[0].n,1);
    await assert.rejects(db.query("select public.bn_save_content($1::jsonb,$2)",[JSON.stringify({...content,version:3,ai_title:"Overwritten"}),2]),/immutable/);
    await assert.rejects(db.query("select public.bn_save_content($1::jsonb,$2)",[JSON.stringify({...content,version:3,variants:[{...content.variants[0],title:"Overwritten"}]}),2]),/immutable/);
    await assert.rejects(db.query("update public.content_variants set copy='Changed' where id=$1",[variantId]),/immutable/);
    await assert.rejects(db.query("select public.bn_save_content($1::jsonb,$2)",[JSON.stringify({...content,version:3}),0]),/version_conflict/);
    await db.query("insert into storage.objects(bucket_id,name) values('brand-assets',$1)",[`${owner}/${brandId}/${randomUUID()}`]);
    await db.query("select set_config('request.jwt.claim.sub',$1,false)",[other]);
    assert.equal((await db.query<{n:number}>("select count(*)::int n from public.brands")).rows[0].n,0);
    assert.equal((await db.query<{n:number}>("select count(*)::int n from public.contents")).rows[0].n,0);
    assert.equal((await db.query<{n:number}>("select count(*)::int n from storage.objects")).rows[0].n,0);
    await assert.rejects(db.query("select public.bn_save_brand($1::jsonb)",[JSON.stringify(brand)]),/insufficient_privilege/);
    await assert.rejects(db.query("select * from public.ai_records"),/permission denied/);
    await assert.rejects(db.query("select public.bn_claim_lock('test',$1)",[randomUUID()]),/permission denied/);
    await db.exec("reset role;set role anon");await assert.rejects(db.query("select * from public.contents"),/permission denied/);
    await db.exec("reset role;set role service_role");const token=randomUUID();
    assert.equal((await db.query<{ok:boolean}>("select public.bn_claim_lock('test',$1) ok",[token])).rows[0].ok,true);
    assert.equal((await db.query<{ok:boolean}>("select public.bn_claim_lock('test',$1) ok",[randomUUID()])).rows[0].ok,false);
    await db.query("select public.bn_release_lock('test',$1)",[randomUUID()]);assert.equal((await db.query<{ok:boolean}>("select public.bn_claim_lock('test',$1) ok",[randomUUID()])).rows[0].ok,false);
    await db.query("select public.bn_release_lock('test',$1)",[token]);assert.equal((await db.query<{ok:boolean}>("select public.bn_claim_lock('test',$1) ok",[randomUUID()])).rows[0].ok,true);
  }finally{await db.close();}
});
