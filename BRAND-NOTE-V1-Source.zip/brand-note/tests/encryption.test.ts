import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { encryptRecord,decryptRecord } from "../lib/chatgpt/encryption";
test("encrypted credentials reject key mismatch, tampering and host/record swaps",()=>{
  const secret=randomBytes(32).toString("base64"),value={refresh_token:"fake-private-test"};const cipher=encryptRecord(value,secret,"host/credentials");
  assert.ok(!cipher.includes(value.refresh_token));assert.deepEqual(decryptRecord(cipher,secret,"host/credentials"),value);
  assert.throws(()=>decryptRecord(cipher,secret,"different-host/credentials"));assert.throws(()=>decryptRecord(cipher,randomBytes(32).toString("base64"),"host/credentials"));
  const changed=JSON.parse(cipher);changed.data=Buffer.from("altered").toString("base64");assert.throws(()=>decryptRecord(JSON.stringify(changed),secret,"host/credentials"));assert.throws(()=>encryptRecord(value,"bad","host/credentials"));
});
