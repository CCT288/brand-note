import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { prepareAuthorization, validateCallback, publicConnection, type Credentials } from "../lib/chatgpt/contracts";
import { requireLocalRequest } from "../lib/chatgpt/local-access";
import { completedOutput } from "../lib/chatgpt/stream";

test("authorization requests use loopback, distinct state and nonce, correct PKCE and plan scope", () => {
  const { pending, url } = prepareAuthorization("http://127.0.0.1:3010/auth/callback", "urn:uuid:123");
  const params = new URL(url).searchParams;
  assert.equal(params.get("client_id"), "dynamic_agent_client");
  assert.equal(params.get("redirect_uri"), pending.redirect_uri);
  assert.notEqual(pending.state, pending.nonce);
  assert.equal(params.get("code_challenge"), createHash("sha256").update(pending.verifier).digest("base64url"));
  assert.ok(params.get("scope")?.includes("chatgpt.tokens.use.direct"));
  const returning = new URL(prepareAuthorization(pending.redirect_uri, "urn:uuid:123", { client_id: "issued-id" }).url);
  assert.equal(returning.searchParams.get("client_id"), "issued-id");
  assert.equal(returning.searchParams.get("agent_name_hint"), null);
  assert.throws(() => prepareAuthorization("http://localhost:3010/auth/callback", "urn:uuid:123"));
});
test("callback rejects wrong state, expired attempt, denial, missing registration and changed client", () => {
  const { pending } = prepareAuthorization("http://127.0.0.1:3010/auth/callback", "urn:uuid:123");
  const valid = new URLSearchParams({ state: pending.state, code: "code", client_id: "issued-id" });
  assert.deepEqual(validateCallback(valid, pending), { clientId: "issued-id", code: "code" });
  assert.throws(() => validateCallback(new URLSearchParams({ state: "wrong" }), pending));
  assert.throws(() => validateCallback(valid, { ...pending, expires_at: 0 }));
  assert.throws(() => validateCallback(new URLSearchParams({ state: pending.state, error: "access_denied" }), pending));
  assert.throws(() => validateCallback(new URLSearchParams({ state: pending.state, code: "code" }), pending));
  assert.throws(() => validateCallback(valid, { ...pending, client_id: "other-client" }));
});
test("public connection excludes credentials and identity alone cannot enable plan usage", () => {
  const credentials: Credentials = { access_token: "SECRET", refresh_token: "SECRET2", id_token: "SECRET3", scope: "openid profile", subject: "subject", email: "test@example.invalid", client_id: "issued", token_type: "Bearer", expires_in: 3600, expires_at: Date.now() + 3600000 };
  assert.equal(publicConnection(credentials).planEnabled, false);
  assert.ok(!JSON.stringify(publicConnection(credentials)).includes("SECRET"));
  assert.equal(publicConnection({ ...credentials, scope: "chatgpt.tokens.use.direct" }).planEnabled, true);
  assert.equal(publicConnection({ ...credentials, scope: "chatgpt.tokens.use.direct", reauth_required: true }).planEnabled, false);
});
test("local API rejects remote hosts and cross-origin mutations", () => {
  assert.throws(() => requireLocalRequest(new Request("https://example.com/api", { headers: { host: "example.com" } })));
  assert.throws(() => requireLocalRequest(new Request("http://127.0.0.1:3010/api", { headers: { host: "evil.example:3010" } })));
  assert.throws(() => requireLocalRequest(new Request("http://127.0.0.1:3010/api", { headers: { host: "127.0.0.1:3010", origin: "https://evil.example" } }), true));
  assert.doesNotThrow(() => requireLocalRequest(new Request("http://127.0.0.1:3010/api", { headers: { host: "127.0.0.1:3010", origin: "http://127.0.0.1:3010" } }), true));
  assert.equal(requireLocalRequest(new Request("http://localhost:3010/api", { headers: { host: "127.0.0.1:3010", origin: "http://127.0.0.1:3010" } }), true), "http://127.0.0.1:3010");
});
function streamOf(events: unknown[], split = false) {
  const data = events.map(event => `data: ${JSON.stringify(event)}\n\n`).join("");
  const encoder = new TextEncoder();
  return new Response(new ReadableStream({ start(controller) {
    if (split) { const bytes = encoder.encode(data); for (let i = 0; i < bytes.length; i += 3) controller.enqueue(bytes.slice(i, i + 3)); }
    else controller.enqueue(encoder.encode(data));
    controller.close();
  } }));
}
test("SSE accepts completed output across split UTF8 chunks", async () => {
  const event = { type: "response.completed", response: { status: "completed", output: [{ type: "message", content: [{ type: "output_text", text: "中文测试" }] }] } };
  assert.equal(await completedOutput(streamOf([event], true)), "中文测试");
});
test("SSE accepts collected text only after a successful terminal event", async () => {
  const events = [
    { type: "response.output_text.delta", delta: "中文" },
    { type: "response.output_text.delta", delta: "测试" },
    { type: "response.completed", response: { status: "completed", output: [] } },
  ];
  assert.equal(await completedOutput(streamOf(events, true)), "中文测试");
  await assert.rejects(completedOutput(streamOf(events.slice(0, 2))), /没有收到完成确认/);
  await assert.rejects(completedOutput(streamOf([...events.slice(0, 2), { type: "response.failed", response: { error: { code: "subscription_sharing_usage_limit_exceeded" } } }])), /生成未完成/);
});
test("SSE rejects plausible partial text, incomplete status, quota error and empty output", async () => {
  await assert.rejects(completedOutput(streamOf([{ type: "response.output_text.delta", delta: "looks complete" }])));
  await assert.rejects(completedOutput(streamOf([{ type: "response.incomplete", response: { status: "incomplete" } }])));
  await assert.rejects(completedOutput(streamOf([{ type: "response.failed", response: { error: { code: "subscription_sharing_usage_limit_exceeded" } } }])), /生成未完成/);
  await assert.rejects(completedOutput(streamOf([{ type: "response.completed", response: { status: "completed", output: [] } }])));
});
