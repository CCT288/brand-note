import type { NextConfig } from "next";
const config: NextConfig = {
  devIndicators: false,
  logging: { incomingRequests: false },
  outputFileTracingExcludes: { "/*": ["./.runtime/**/*", "./.env*"] },
};
export default config;
