import type { Brand, Content } from "./domain";

export function recentHistory(contents: Content[], brandId: string) {
  return contents.filter(c => c.brief.brand_id === brandId && c.archived_at).sort((a,b) => b.archived_at!.localeCompare(a.archived_at!)).slice(0,30);
}
export function historyCheck(contents: Content[]) {
  const titleOpenings: Record<string,number> = {};
  const sentences: Record<string,number> = {};
  for (const item of contents) {
    const title = item.final_title || item.ai_title;
    const opening = title.slice(0,2); if (opening) titleOpenings[opening] = (titleOpenings[opening] ?? 0) + 1;
    (item.final_copy || item.ai_copy).split(/[。！!？?\n]/).map(s => s.trim()).filter(s => s.length > 5).forEach(s => { sentences[s] = (sentences[s] ?? 0) + 1; });
  }
  const lastFive = contents.slice(0,5);
  const types: Record<string,number> = {};
  lastFive.forEach(c => { const type = c.brief.content_type; types[type] = (types[type] ?? 0)+1; });
  const concentrated = Object.entries(types).find(([type,count]) => type !== "AI 判断" && count >= 3);
  return { repeated_openings: Object.entries(titleOpenings).filter(([,n]) => n >= 2).map(([s]) => s), repeated_sentences: Object.entries(sentences).filter(([,n]) => n >= 2).map(([s]) => s), recent: contents.map(c => ({ title: c.final_title || c.ai_title, copy: c.final_copy || c.ai_copy, topic: c.brief.topic || c.brief.raw_input, type: c.brief.content_type })), warning: concentrated ? `最近${concentrated[0]}内容较多，这次如果素材允许，可以尝试从人物或产品切入。` : "" };
}
export const longTermPreferences: Record<string,string> = { shorter_titles: "更偏好短标题。", concise_copy: "更偏好精简正文。", natural_copy: "更偏好自然具体的表达，减少广告感。", bold_copy: "更偏好大胆但不低俗的表达。" };
export function learnedMemory(brand: Brand, contents: Content[]) {
  const history = recentHistory(contents, brand.id);
  const sources: Record<string,Set<string>> = {};
  for (const c of history) {
    const original = c.variants.find(v => v.id === c.selected_variant_id);
    if (original && c.final_title.length > 0 && c.final_title.length <= original.title.length * 0.7) (sources.shorter_titles ??= new Set()).add(c.id);
    if (original && c.final_copy.length > 0 && c.final_copy.length <= original.copy.length * 0.7) (sources.concise_copy ??= new Set()).add(c.id);
    for (const revision of c.revisions) if (revision.applied && revision.preference_key && longTermPreferences[revision.preference_key]) (sources[revision.preference_key] ??= new Set()).add(c.id);
  }
  return Object.entries(sources).filter(([,ids]) => ids.size >= 3).map(([key,ids]) => ({ key, content: longTermPreferences[key], source_count: ids.size, source_ids: [...ids], confidence: Math.min(0.9,0.5 + ids.size * 0.05) }));
}
