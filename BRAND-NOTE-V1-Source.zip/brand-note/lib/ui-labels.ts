export const statusLabels = { Draft: "草稿", Used: "已采用", Published: "已发布" } as const;
export const factLabels = { Basic: "基本信息", Products: "产品", People: "人物", Space: "空间", Events: "活动", Other: "其他" } as const;
export const revisionLabels = { title: "改写标题", copy: "改写正文", feedback: "反馈修改", manual: "手动编辑", selection: "选择方向" } as const;
