import type { Content } from "./domain";
export type ContentView = Omit<Content,"stage_results">;
export async function api<T>(url:string,options?:RequestInit):Promise<T> {
  const response=await fetch(url,{...options,cache:"no-store"});
  const data=await response.json();
  if(!response.ok) throw new Error(`${data.error ?? "操作未完成"} (${data.code ?? response.status})`);
  return data;
}
export function post(body:unknown,method="POST"):RequestInit {return {method,headers:{"Content-Type":"application/json"},body:JSON.stringify(body)};}
