import { createServerClient } from "@supabase/ssr";
import { createClient } from "@supabase/supabase-js";
import { cookies } from "next/headers";
import { ConnectionError } from "@/lib/chatgpt/contracts";

export const cloudMode = () => process.env.APP_DEPLOYMENT === "cloud" || !!process.env.NETLIFY;
export function configured() { return !!(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY && process.env.APP_OWNER_ID); }
export async function userClient() {
  if (!configured()) throw new ConnectionError("请先配置 Supabase 和唯一使用者。", "database_not_configured", 503);
  const jar = await cookies();
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!, {
    cookies: { getAll: () => jar.getAll(), setAll: values => { values.forEach(({ name, value, options }) => jar.set(name, value, options)); } },
  });
}
export function adminClient() {
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.SUPABASE_SECRET_KEY) throw new ConnectionError("服务器连接存储未配置。", "connection_store_missing", 503);
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SECRET_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
}
