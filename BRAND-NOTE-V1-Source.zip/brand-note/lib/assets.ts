import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join,resolve } from "node:path";
import { randomUUID } from "node:crypto";
import type { Asset } from "./domain";
import { configured,userClient } from "./supabase/server";
import { saveAsset } from "./repository";
import { ConnectionError } from "./chatgpt/contracts";

const imageMime = ["image/png","image/jpeg","image/webp"];
export async function uploadAsset(file: File, brandId: string, owner: string) {
  if (!imageMime.includes(file.type) || file.size > 5_000_000 || file.size === 0) throw new ConnectionError("请选择小于 5 MB 的 PNG、JPEG 或 WebP 图片 / 视频截图。","invalid_file");
  const id = randomUUID(); const bytes = new Uint8Array(await file.arrayBuffer());
  const valid = file.type === "image/png" ? bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71 : file.type === "image/jpeg" ? bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255 : Buffer.from(bytes.slice(0,4)).toString() === "RIFF" && Buffer.from(bytes.slice(8,12)).toString() === "WEBP";
  if (!valid) throw new ConnectionError("图片内容与文件格式不一致。","invalid_file");
  const path = `${owner}/${brandId}/${id}`;
  if (configured()) { const db = await userClient(); const { error } = await db.storage.from("brand-assets").upload(path,bytes,{ contentType: file.type,upsert: false }); if (error) throw new ConnectionError("素材上传未完成。","upload_failed",503); }
  else { const dir = resolve(/* turbopackIgnore: true */ ".runtime/assets"); await mkdir(dir,{ recursive: true,mode: 0o700 }); await writeFile(join(dir,id),bytes,{ flag:"wx",mode:0o600 }); }
  return saveAsset({ id,brand_id:brandId,content_id:null,name:file.name.slice(0,200),type:file.type,path,created_at:new Date().toISOString(),analysis_json:null });
}
export async function assetBytes(asset: Asset) {
  if (configured()) { const db = await userClient(); const { data,error } = await db.storage.from("brand-assets").download(asset.path); if (error || !data) throw new ConnectionError("素材无法读取，可能已暂停服务。","asset_unavailable",503); return new Uint8Array(await data.arrayBuffer()); }
  return readFile(/* turbopackIgnore: true */ join(/* turbopackIgnore: true */ resolve(/* turbopackIgnore: true */ ".runtime/assets"),asset.path.split("/").at(-1)!));
}
