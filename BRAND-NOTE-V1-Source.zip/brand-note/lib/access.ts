import { requireLocalRequest, errorResponse } from "./chatgpt/local-access";
import { ConnectionError } from "./chatgpt/contracts";
import { cloudMode, configured, userClient } from "./supabase/server";

export async function authorize(request: Request, mutation = false) {
  if (!cloudMode() && !configured()) {
    requireLocalRequest(request, mutation);
    return "local-owner";
  }
  if (!configured()) throw new ConnectionError("云端尚未配置，操作未执行。", "cloud_not_configured", 503);
  const origin = process.env.APP_URL;
  if (!origin || request.headers.get("host") !== new URL(origin).host || (mutation && request.headers.get("origin") !== origin)) throw new ConnectionError("请求来源不允许。", "invalid_origin", 403);
  const supabase = await userClient();
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user || data.user.id !== process.env.APP_OWNER_ID) throw new ConnectionError("请使用指定账号登录。", "unauthorized", 401);
  return data.user.id;
}
export { errorResponse };
export function json(value: unknown, status = 200) { return Response.json(value, { status, headers: { "Cache-Control": "no-store" } }); }
