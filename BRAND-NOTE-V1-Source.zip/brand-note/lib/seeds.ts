import { z } from "zod";
import { brandSchema, type Brand } from "./domain";
import { readRecord } from "./chatgpt/storage";

// Optional owner-provided brands are private runtime data, never public source.
export async function seedBrands(): Promise<Brand[]> {
  return await readRecord("demo-brands.json", z.array(brandSchema)) ?? [];
}
