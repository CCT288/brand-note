import { randomUUID } from "node:crypto";
import { z } from "zod";
import { getContent, saveContent } from "../repository";
import { modelJson } from "./model";
import type { Revision } from "../domain";
import { ConnectionError } from "../chatgpt/contracts";

export const rewriteRequest = z.object({ variant_id: z.string().uuid(), title: z.string().min(1).max(100), copy: z.string().min(1).max(5000), kind: z.enum(["title","copy","feedback"]), feedback: z.string().max(2000).default(""), scope: z.enum(["title","copy","paragraph"]).default("copy"), paragraph: z.string().max(5000).default(""), adjustment: z.enum(["natural","internet","bold","shorter"]).optional() });
export async function rewrite(id: string, owner: string, request: z.infer<typeof rewriteRequest>) {
  const item = await getContent(id,owner);
  const variant = item.variants.find(v => v.id === request.variant_id);
  if (!variant) throw new ConnectionError("找不到要修改的方向。","variant_not_found",404);
  if (request.scope === "paragraph" && (!request.paragraph || !request.copy.includes(request.paragraph))) throw new ConnectionError("请填入当前正文中要修改的段落。","invalid_paragraph");
  const context = { brand: item.brand_snapshot, brief: item.brief, direction: variant.direction, title: request.title, copy: request.copy, feedback: request.feedback, scope: request.scope, paragraph: request.paragraph, adjustment: request.adjustment };
  const revisions: Revision[] = [];
  let suggestion: unknown;
  if (request.kind === "title") {
    const schema = z.object({ titles: z.array(z.string().min(1).max(100)).length(3) });
    const output = await modelJson(item.model,schema,"只重写标题，返回三个不同新标题，不输出正文，不改变 Direction。",context);
    suggestion = { titles: output.titles };
    output.titles.forEach(title => revisions.push({ id:randomUUID(),variant_id:variant.id,kind:"title",title,applied:false,created_at:new Date().toISOString() }));
  } else {
    const schema = z.object({ replacement: z.string().min(1).max(5000), reason: z.string() });
    const output = await modelJson(item.model,schema,request.kind === "copy" ? "只重写正文，不输出标题，不改变 Direction。replacement 返回完整新正文。" : "根据自由反馈修改指定部分，给出建议供用户应用。scope=title 时只返回新标题；scope=copy 时只返回完整新正文；scope=paragraph 时只返回指定段落的新版本，保留其他段落原样。",context);
    suggestion = output;
    const targetTitle = request.kind === "feedback" && request.scope === "title";
    if (targetTitle && output.replacement.length > 100) throw new ConnectionError("标题建议过长。","invalid_model_format",422);
    const copy = request.scope === "paragraph" && request.kind === "feedback" ? request.copy.replace(request.paragraph,output.replacement) : output.replacement;
    const preference = request.adjustment === "natural" ? "natural_copy" : request.adjustment === "shorter" ? "concise_copy" : request.adjustment === "bold" ? "bold_copy" : undefined;
    revisions.push({ id:randomUUID(),variant_id:variant.id,kind:request.kind,...(targetTitle ? {title:output.replacement} : {copy}),feedback:request.feedback,preference_key:preference,applied:false,created_at:new Date().toISOString() });
  }
  item.revisions.push(...revisions); await saveContent(item,item.version);
  return { suggestion, revisions, basis:{ title:request.title,copy:request.copy } };
}
