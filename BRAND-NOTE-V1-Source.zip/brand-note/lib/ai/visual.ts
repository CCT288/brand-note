import { visualSchema, type Asset, type Brief } from "../domain";
import { assetBytes } from "../assets";
import { modelJson } from "./model";

export async function analyzeImage(asset: Asset, model: string, brief: Brief) {
  const bytes = await assetBytes(asset);
  return modelJson(model,visualSchema,"形成完整 Visual Brief：Who、Action、Scene、Mood、Notable details、Possible content angles、Avoid over-interpreting。直接观察和可能角度分开，避免推断身份与品牌事实。",{ brief },[`data:${asset.type};base64,${Buffer.from(bytes).toString("base64")}`]);
}
