import { randomUUID } from "node:crypto";
import { z } from "zod";
import { criticSchema, directionsSchema, selectionSchema, understandingSchema, writingSchema, type Content, type Brief } from "../domain";
import { getBrand, getContent, listContents, listAssets, saveContent, saveAsset } from "../repository";
import { recentHistory, historyCheck } from "../history";
import { readRecord } from "../chatgpt/storage";
import { brandSchema,styleSchema,settingsSchema } from "../domain";
import { ConnectionError } from "../chatgpt/contracts";
import { modelJson } from "./model";
import { analyzeImage } from "./visual";

const brandContextSchema = z.object({ name: z.string(), description: z.string(), keywords: z.array(z.string()), facts: brandSchema.shape.facts, voice: brandSchema.shape.voice, preferences: brandSchema.shape.memory, style: styleSchema });
const historyResultSchema = z.object({ repeated_openings: z.array(z.string()), repeated_sentences: z.array(z.string()), recent: z.array(z.object({ title:z.string(),copy:z.string(),topic:z.string(),type:z.string() })), warning:z.string() });

export async function createGeneration(owner: string, brief: Brief) {
  const brand = await getBrand(brief.brand_id);
  const assets = await listAssets(brief.brand_id);
  if (brief.asset_ids.some(id => !assets.some(a => a.id === id))) throw new ConnectionError("素材归属或状态不匹配。", "invalid_assets",400);
  const requestedAssets = brief.asset_ids.map(id => assets.find(a => a.id === id)!);
  const generationAssets = requestedAssets.map(a => a.content_id ? { ...a, id: randomUUID(), created_at: new Date().toISOString() } : a);
  brief = { ...brief, asset_ids: generationAssets.map(a => a.id) };
  const settings = await readRecord("settings.json",settingsSchema) ?? settingsSchema.parse({});
  const item: Content = { id: randomUUID(), owner_id: owner, brief, brand_snapshot: brand, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), archived_at: null, status: "Used", stage: 0, stage_results: {}, variants: [], revisions: [], selected_variant_id: null, ai_title: "", ai_copy: "", final_title: "", final_copy: "", warning: "", error: null, model: settings.text_model, vision_model: settings.vision_model, critic_attempts: 0, version: 0 };
  const saved = await saveContent(item,null);
  for (const asset of generationAssets) { await saveAsset({ ...asset, content_id: item.id }); }
  return saved;
}
export async function advanceGeneration(id: string, owner: string) {
  const item = await getContent(id,owner); const version = item.version;
  if (item.stage === 7) return item;
  const context = { brand: item.brand_snapshot, brief: item.brief, ...item.stage_results };
  let retryKey = `format_retries_${item.stage}`;
  try {
    if (Number(item.stage_results[retryKey] ?? 0) >= 3) throw new ConnectionError("结构化结果已修复两次，仍未通过，请调整输入重新生成。", "format_repair_exhausted",422);
    if (item.stage === 6 && item.critic_attempts >= 1 && criticSchema.safeParse(item.stage_results.critic).data?.passed === false) throw new ConnectionError("文案重写后仍未通过检查，请调整输入重新生成。", "critic_failed",422);
    if (item.stage === 0) {
      item.stage_results.brand_context = brandContextSchema.parse({ name: item.brand_snapshot.name, description: item.brand_snapshot.description, keywords: item.brand_snapshot.keywords, facts: item.brand_snapshot.facts, voice: item.brand_snapshot.voice, preferences: item.brand_snapshot.memory, style: item.brief.style_json });
    } else if (item.stage === 1) {
      const assets = (await listAssets(item.brief.brand_id)).filter(a => item.brief.asset_ids.includes(a.id));
      const unanalyzed = assets.find(a => !a.analysis_json);
      if (unanalyzed) {
        // One image per request keeps the flow resumable within function time limits.
        retryKey = `asset_format_retries_${unanalyzed.id}`;
        if (Number(item.stage_results[retryKey] ?? 0) >= 3) throw new ConnectionError("图片分析结果已修复两次，仍未通过。", "format_repair_exhausted",422);
        unanalyzed.analysis_json = await analyzeImage(unanalyzed,item.vision_model,item.brief);
        await saveAsset(unanalyzed);
        item.error = null;
        return await saveContent(item,version);
      }
      item.stage_results.visual = assets.map(a => a.analysis_json);
      item.stage_results.understanding = await modelJson(item.model,understandingSchema,"理解这次内容：发生了什么、主体、具体值得讲的内容、重要信息和不能推断的事。不要开始写标题或正文。",{ ...context, visual: item.stage_results.visual },[],item.error ?? "");
      if(item.brief.content_type === "AI 判断") item.brief.content_type = understandingSchema.parse(item.stage_results.understanding).content_type;
    } else if (item.stage === 2) {
      const history = recentHistory(await listContents(owner,true,item.brief.brand_id),item.brief.brand_id);
      const checked = historyResultSchema.parse(historyCheck(history)); item.stage_results.history = checked; item.warning = checked.warning;
    } else if (item.stage === 3) {
      const output = await modelJson(item.model,directionsSchema,"先想至少六个不同内容切入方向。每个方向明确 angle、reason、difference。不要输出标题正文，不要仅按文艺/高级/活泼等语气分类。id 必须唯一。",context,[],item.error ?? "");
      if (new Set(output.directions.map(d => d.id)).size !== output.directions.length) throw new ConnectionError("方向编号重复。","invalid_model_format",422);
      item.stage_results.directions = output;
    } else if (item.stage === 4) {
      const directions = directionsSchema.parse(item.stage_results.directions);
      const selection = await modelJson(item.model,selectionSchema,"从六个候选中筛选三个适合品牌、贴合素材且内容策略有明显差异的方向。避开近期历史的角度和结构，ids 必须是候选中三个不同 id。",context,[],item.error ?? "");
      if (new Set(selection.ids).size !== 3 || selection.ids.some(id => !directions.directions.some(d => d.id === id))) throw new ConnectionError("方向选择不符合约定。","invalid_model_format",422);
      item.stage_results.selection = selection;
    } else if (item.stage === 5) {
      const selection = selectionSchema.parse(item.stage_results.selection);
      const output = await modelJson(item.model,writingSchema,"分别按选定三个方向写标题和正文。若 critic.rewrite_guidance 存在，逐条执行其中的重写要求并改变有问题的内容结构，不只换词。direction_id 与 selection ids 一一对应。用户必须出现/避免出现的信息优先于默认风格；不编造事实。六个滑杆只调整本次表达。每篇只完成该方向的一项叙述任务，不要全都回到品牌见面或到店邀约。标题说过的意思正文不再同义复述；文案短于素材信息量，不为凑长度添加三段式。资料有限可用一两段简洁成稿，不编造调酒步骤，不替出镜人物发言。",context,[],item.error ?? "");
      if (new Set(output.pieces.map(p => p.direction_id)).size !== 3 || output.pieces.some(p => !selection.ids.includes(p.direction_id))) throw new ConnectionError("写作方向不符合约定。","invalid_model_format",422);
      item.stage_results.writing = output;
      delete item.stage_results.critic;
    } else if (item.stage === 6) {
      const report = await modelJson(item.model,criticSchema,"内部审核当前三篇文案，检查编造事实、模板广告、空洞抒情、排比、标题正文重复、与历史结构相似、三个方向是否只是换语气。存在实质问题则 passed=false，并给出明确重写要求。可正常使用的结果则通过。只因实质性事实越界、方向切入点没有区别或明显违反用户要求而拒绝；措辞偏好或可进一步润色的问题不应导致失败。品牌正常打招呼可以保留，但同一篇反复说同一意思需重写。不因没有写出未提供的画面细节而拒绝。",context,[],item.error ?? "");
      item.stage_results.critic = report;
      if (!report.passed) {
        if (item.critic_attempts >= 1) throw new ConnectionError("文案检查仍未通过，请补充素材或调整需求后重新生成。", "critic_failed",422);
        item.critic_attempts += 1; item.stage = 5; item.error = null; return await saveContent(item,version);
      }
      const directions = directionsSchema.parse(item.stage_results.directions);
      item.variants = writingSchema.parse(item.stage_results.writing).pieces.map(p => ({ id: randomUUID(), direction: directions.directions.find(d => d.id === p.direction_id)!, title: p.title, copy: p.copy }));
    }
    item.stage += 1; item.error = null;
    return await saveContent(item,version);
  } catch (error) {
    const connection = error instanceof ConnectionError ? error : new ConnectionError("本次请求中断，输入和进度已保留。", "generation_interrupted",503);
    const count = Number(item.stage_results[retryKey] ?? 0);
    if (connection.code === "invalid_model_format") item.stage_results[retryKey] = count + 1;
    item.error = connection.message;
    const saved = await saveContent(item,version);
    if (connection.code === "invalid_model_format" && count < 2) return { ...saved, retryable: true };
    throw connection;
  }
}
export function publicContent(item: Content) {
  // Internal reasoning and Critic are never serialized to the client.
  const { stage_results, ...visible } = item;
  const understanding = understandingSchema.safeParse(stage_results.understanding);
  return { ...visible, understanding: understanding.success ? understanding.data : null };
}
export const editSchema = z.object({ expected_version: z.number().int(), variant_id: z.string().uuid(), title: z.string().min(1).max(100), copy: z.string().min(1).max(5000), status: z.enum(["Draft","Used","Published"]), archive: z.boolean().default(false), applied_revision_id: z.string().uuid().optional() });
