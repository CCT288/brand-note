import { z } from "zod";
import { randomUUID } from "node:crypto";
import { brandSchema, contentSchema, assetSchema, type Brand, type Content, type Asset } from "./domain";
import { seedBrands } from "./seeds";
import { readRecord, writeRecord, withFileLock } from "./chatgpt/storage";
import { userClient, configured } from "./supabase/server";
import { ConnectionError } from "./chatgpt/contracts";
import { learnedMemory } from "./history";

const workspaceSchema = z.object({ brands: z.array(brandSchema), contents: z.array(contentSchema), assets: z.array(assetSchema) });
type Workspace = z.infer<typeof workspaceSchema>;
async function localWorkspace() { return await readRecord("workspace.json", workspaceSchema) ?? { brands: await seedBrands(), contents: [], assets: [] }; }
async function localMutation<T>(action: (data: Workspace) => T) {
  return withFileLock("workspace", async () => { const data = await localWorkspace(); const result = action(data); await writeRecord("workspace.json", data); return result; });
}
function check(error: { message: string; code?: string } | null) { if (error) throw new ConnectionError(error.code === "40001" ? "内容已更新，请重新读取后再操作。" : "资料库操作未完成，现有内容已保留。", error.code === "40001" ? "version_conflict" : "database_error", error.code === "40001" ? 409 : 503); }
export async function listBrands(): Promise<Brand[]> {
  if (!configured()) return (await localWorkspace()).brands;
  const db = await userClient(); const { data, error } = await db.from("brands").select("data_json").order("created_at"); check(error);
  return (data ?? []).map(row => brandSchema.parse(row.data_json));
}
export async function getBrand(id: string) {
  const brand = (await listBrands()).find(b => b.id === id);
  if (!brand) throw new ConnectionError("没有找到这个品牌。", "brand_not_found", 404);
  return brand;
}
export async function saveBrand(brand: Brand) {
  const validated = brandSchema.parse({ ...brand, updated_at: new Date().toISOString() });
  if (!configured()) return localMutation(data => { const index = data.brands.findIndex(b => b.id === brand.id); if (index < 0) data.brands.push(validated); else data.brands[index] = validated; return validated; });
  const db = await userClient(); const { error } = await db.rpc("bn_save_brand", { payload: validated }); check(error); return validated;
}
export async function initializeBrands() {
  if ((await listBrands()).length) return;
  for (const brand of await seedBrands()) await saveBrand(brand);
}
export async function listContents(owner: string, archivedOnly = false, brandId?: string): Promise<Content[]> {
  if (!configured()) return (await localWorkspace()).contents.filter(c => c.owner_id === owner && (!archivedOnly || c.archived_at) && (!brandId || c.brief.brand_id===brandId)).sort((a,b) => b.updated_at.localeCompare(a.updated_at));
  const db = await userClient(); let query = db.from("contents").select("data_json").eq("user_id", owner).order(archivedOnly ? "archived_at" : "updated_at", { ascending: false });
  if (brandId) query = query.eq("brand_id",brandId);
  if (archivedOnly) query = query.not("archived_at", "is", null);
  if (archivedOnly && brandId) query = query.limit(30);
  const { data, error } = await query; check(error); return (data ?? []).map(row => contentSchema.parse(row.data_json));
}
export async function getContent(id: string, owner: string) {
  if (configured()) { const db = await userClient(); const { data, error } = await db.from("contents").select("data_json").eq("id",id).eq("user_id",owner).maybeSingle(); check(error); if (data) return contentSchema.parse(data.data_json); }
  else { const item = (await localWorkspace()).contents.find(c => c.id === id && c.owner_id === owner); if (item) return item; }
  throw new ConnectionError("没有找到这篇内容。", "content_not_found", 404);
}
export async function saveContent(content: Content, expectedVersion: number | null) {
  const item = contentSchema.parse({ ...content, version: (expectedVersion ?? -1) + 1, updated_at: new Date().toISOString() });
  if (!configured()) return localMutation(data => {
    const index = data.contents.findIndex(c => c.id === item.id);
    const old = data.contents[index];
    if ((old?.version ?? null) !== expectedVersion) throw new ConnectionError("内容已更新，请重新读取后再操作。", "version_conflict",409);
    if (old?.variants.length && JSON.stringify(old.variants) !== JSON.stringify(item.variants)) throw new ConnectionError("AI 原稿不能覆盖。", "original_immutable",409);
    if (old?.ai_title && (old.ai_title !== item.ai_title || old.ai_copy !== item.ai_copy)) throw new ConnectionError("AI 原稿不能覆盖。", "original_immutable",409);
    if (index < 0) data.contents.push(item); else data.contents[index] = item;
    return item;
  });
  const db = await userClient(); const { error } = await db.rpc("bn_save_content", { payload: item, expected_version: expectedVersion }); check(error); return item;
}
export async function listAssets(brandId?: string): Promise<Asset[]> {
  if (!configured()) return (await localWorkspace()).assets.filter(a => !brandId || a.brand_id === brandId);
  const db = await userClient(); let query = db.from("assets").select("data_json"); if (brandId) query = query.eq("brand_id",brandId);
  const { data,error } = await query; check(error); return (data ?? []).map(row => assetSchema.parse(row.data_json));
}
export async function saveAsset(asset: Asset) {
  if (!configured()) return localMutation(data => { const i = data.assets.findIndex(a => a.id === asset.id); if (i < 0) data.assets.push(asset); else data.assets[i] = asset; return asset; });
  const db = await userClient(); const { error } = await db.from("assets").upsert({ id: asset.id, user_id: process.env.APP_OWNER_ID, brand_id: asset.brand_id, content_id: asset.content_id, file_path: asset.path, type: asset.type, analysis_json: asset.analysis_json, data_json: asset }); check(error); return asset;
}
export async function updateMemory(brandId: string, owner: string) {
  const brand = await getBrand(brandId); const entries = learnedMemory(brand, await listContents(owner,true,brandId));
  brand.memory = entries.map(entry => ({ ...entry, id: brand.memory.find(old => old.key === entry.key)?.id ?? randomUUID() }));
  await saveBrand(brand);
}
