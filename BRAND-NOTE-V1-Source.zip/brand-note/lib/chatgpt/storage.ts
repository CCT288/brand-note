import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, writeFile, unlink, open } from "node:fs/promises";
import { resolve, join } from "node:path";
import { z } from "zod";
import { ConnectionError } from "./contracts";
import { cloudMode,adminClient } from "../supabase/server";
import { encryptRecord,decryptRecord } from "./encryption";

// These local runtime records must never be copied into server build artifacts.
const directory = () => resolve(/* turbopackIgnore: true */ process.env.BRAND_NOTE_RUNTIME_DIR ?? ".runtime");
export async function readRecord<T>(name: string, schema: z.ZodType<T>): Promise<T | null> {
  if(cloudMode()) { const db=adminClient();const host=await hostId();const {data,error}=await db.from("ai_records").select("ciphertext").eq("host_id",host).eq("record_name",name).maybeSingle();if(error)throw new ConnectionError("云端连接记录暂时无法读取。","connection_store_unavailable",503);return data?schema.parse(decryptRecord(data.ciphertext,process.env.BRAND_NOTE_ENCRYPTION_KEY??"",`${host}/${name}`)):null; }
  try { return schema.parse(JSON.parse(await readFile(/* turbopackIgnore: true */ join(/* turbopackIgnore: true */ directory(), name), "utf8"))); }
  catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return null; throw new ConnectionError("本地连接记录无法读取；已保留原文件，请检查配置。", "storage_unavailable", 503); }
}
export async function writeRecord(name: string, value: unknown) {
  if(cloudMode()) { const db=adminClient();const host=await hostId();const {error}=await db.from("ai_records").upsert({host_id:host,record_name:name,ciphertext:encryptRecord(value,process.env.BRAND_NOTE_ENCRYPTION_KEY??"",`${host}/${name}`),updated_at:new Date().toISOString()});if(error)throw new ConnectionError("云端连接记录暂时无法保存。","connection_store_unavailable",503);return; }
  await mkdir(directory(), { recursive: true, mode: 0o700 });
  const temporary = join(directory(), `${name}.${randomUUID()}.tmp`);
  await writeFile(temporary, JSON.stringify(value), { mode: 0o600, flag: "wx" });
  await rename(temporary, join(directory(), name));
}
export async function removeRecord(name: string) {
  if(cloudMode()) {const db=adminClient();const {error}=await db.from("ai_records").delete().eq("host_id",await hostId()).eq("record_name",name);if(error)throw new ConnectionError("连接记录暂时无法移除。","connection_store_unavailable",503);return;}
  try { await unlink(join(directory(), name)); } catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
}
export async function withFileLock<T>(name: string, action: () => Promise<T>): Promise<T> {
  if (!/^[a-zA-Z0-9-]+$/.test(name)) throw new ConnectionError("锁名称不符合约定。", "invalid_lock");
  if(cloudMode()) { const db=adminClient();const lockKey=`${await hostId()}/${name}`;const token=randomUUID();const {data,error}=await db.rpc("bn_claim_lock",{lock_key:lockKey,lock_token:token});if(error)throw new ConnectionError("云端刷新锁无法使用。","connection_lock_unavailable",503);if(!data)throw new ConnectionError("连接或内容正在更新，请稍后重试。","connection_busy",409);try{return await action();}finally{const {error:releaseError}=await db.rpc("bn_release_lock",{lock_key:lockKey,lock_token:token});if(releaseError)throw new ConnectionError("锁释放未确认，请稍后重试。","connection_lock_unavailable",503);} }
  await mkdir(directory(), { recursive: true, mode: 0o700 });
  const path = join(directory(), `${name}.lock`);
  let handle;
  try { handle = await open(path, "wx", 0o600); }
  catch (error) { if ((error as NodeJS.ErrnoException).code === "EEXIST") throw new ConnectionError("连接正在更新，请稍后重试。", "connection_busy", 409); throw error; }
  try { return await action(); } finally { await handle.close(); await unlink(path); }
}
export const withConnectionLock = <T>(action: () => Promise<T>) => withFileLock("connection", action);
export async function hostId() {
  if(cloudMode()) {const host=process.env.BRAND_NOTE_HOST_ID;if(!host?.startsWith("urn:uuid:")||!z.string().uuid().safeParse(host.slice(9)).success)throw new ConnectionError("线上服务需要独立且持久的 host ID。","host_id_missing",503);return host;}
  const schema = z.object({ id: z.string().startsWith("urn:uuid:") });
  const saved = await readRecord("host.json", schema);
  if (saved) return saved.id;
  const id = `urn:uuid:${randomUUID()}`;
  await writeRecord("host.json", { id });
  return id;
}
