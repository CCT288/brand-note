import { createHash, randomBytes } from "node:crypto";
import { z } from "zod";

export const RESOURCE = "https://api.openai.com/v1";
export const PLAN_SCOPE = "chatgpt.tokens.use.direct";
export const SCOPES = `openid profile email offline_access resource.invoke ${PLAN_SCOPE}`;
export const tokenSchema = z.object({ access_token: z.string().min(1), refresh_token: z.string().min(1), id_token: z.string().min(1), expires_in: z.number().positive(), scope: z.string(), token_type: z.literal("Bearer") });
export const credentialSchema = tokenSchema.extend({ subject: z.string().min(1), email: z.string(), client_id: z.string().min(1), expires_at: z.number(), reauth_required: z.boolean().optional() });
export type Credentials = z.infer<typeof credentialSchema>;
export const pendingSchema = z.object({ state: z.string(), nonce: z.string(), verifier: z.string(), redirect_uri: z.string(), expires_at: z.number(), client_id: z.string().optional(), subject: z.string().optional() });
export type PendingAuthorization = z.infer<typeof pendingSchema>;
export class ConnectionError extends Error {
  constructor(message: string, public code: string, public status = 400) { super(message); }
}
export function prepareAuthorization(redirectUri: string, hostId: string, previous?: { client_id: string; subject?: string }) {
  const callback = new URL(redirectUri);
  if (callback.protocol !== "http:" || callback.hostname !== "127.0.0.1" || callback.pathname !== "/auth/callback" || callback.search || callback.hash) throw new ConnectionError("官方授权必须使用本机 127.0.0.1 回调。", "invalid_callback");
  const opaque = () => randomBytes(32).toString("base64url");
  const pending: PendingAuthorization = { state: opaque(), nonce: opaque(), verifier: opaque(), redirect_uri: redirectUri, expires_at: Date.now() + 10 * 60_000, ...previous };
  const url = new URL("https://auth.openai.com/api/accounts/authorize");
  const params: Record<string, string> = { client_id: previous?.client_id ?? "dynamic_agent_client", ext_agent_host_id: hostId, response_type: "code", redirect_uri: redirectUri, scope: SCOPES, resource: RESOURCE, state: pending.state, nonce: pending.nonce, code_challenge_method: "S256", code_challenge: createHash("sha256").update(pending.verifier).digest("base64url") };
  if (!previous) params.agent_name_hint = "BRAND NOTE";
  url.search = new URLSearchParams(params).toString();
  return { url: url.toString(), pending };
}
export function validateCallback(params: URLSearchParams, pending: PendingAuthorization) {
  if (pending.expires_at < Date.now() || params.get("state") !== pending.state) throw new ConnectionError("授权已过期或校验失败，请重新连接。", "invalid_state");
  if (params.has("error")) throw new ConnectionError("授权未完成，现有连接和资料已保留。", "authorization_declined");
  const clientId = params.get("client_id") ?? pending.client_id;
  if (!clientId || clientId === "dynamic_agent_client" || (pending.client_id && pending.client_id !== clientId)) throw new ConnectionError("授权返回的客户端身份不匹配，请重新连接。", "invalid_registration");
  const code = params.get("code");
  if (!code) throw new ConnectionError("授权没有返回有效代码。", "missing_code");
  return { clientId, code };
}
export function publicConnection(credentials: Credentials | null) {
  return { connected: !!credentials && !credentials.reauth_required, planEnabled: !!credentials && !credentials.reauth_required && credentials.scope.split(" ").includes(PLAN_SCOPE), email: credentials?.email ?? null, reauthRequired: credentials?.reauth_required ?? false };
}
