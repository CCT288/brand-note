import { ConnectionError } from "./contracts";

export async function completedOutput(response: Response): Promise<string> {
  if (!response.ok) throw new ConnectionError("OpenAI 暂未接受计划调用；没有切换到付费 API。", `inference_http_${response.status}`, 503);
  if (!response.body) throw new ConnectionError("生成没有返回数据。", "empty_stream", 503);
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let pending = "";
  let result: string | undefined;
  let streamedText = "";
  try {
    while (true) {
      const chunk = await reader.read();
      pending += decoder.decode(chunk.value, { stream: !chunk.done });
      pending = pending.replace(/\r\n/g, "\n");
      let boundary;
      while ((boundary = pending.indexOf("\n\n")) !== -1) {
        const frame = pending.slice(0, boundary);
        pending = pending.slice(boundary + 2);
        const data = frame.split("\n").filter(line => line.startsWith("data:")).map(line => line.slice(5).trimStart()).join("\n");
        if (!data || data === "[DONE]") continue;
        const event = JSON.parse(data);
        if (event.type === "response.output_text.delta" && typeof event.delta === "string") streamedText += event.delta;
        if (["response.failed", "response.incomplete", "error"].includes(event.type)) {
          const rawCode = event.response?.error?.code ?? event.error?.code ?? event.code;
          const code = typeof rawCode === "string" && /^[a-z0-9_]+$/i.test(rawCode) ? rawCode : "inference_failed";
          throw new ConnectionError("生成未完成，可能达到订阅额度或连接中断。现有内容已保留。", code, 503);
        }
        if (event.type === "response.completed") {
          if (event.response?.status !== "completed" || !Array.isArray(event.response.output)) throw new ConnectionError("生成没有有效的完成状态。", "invalid_completion", 503);
          result = event.response.output.filter((item: { type: string }) => item.type === "message").flatMap((item: { content: Array<{ type: string; text?: string }> }) => item.content.filter(c => c.type === "output_text").map(c => c.text ?? "")).join("") || streamedText;
          if (!result) throw new ConnectionError("生成没有可用的文字结果。", "empty_output", 503);
        }
      }
      if (chunk.done) break;
    }
    if (result === undefined) throw new ConnectionError("连接提前结束，没有收到完成确认。", "interrupted_stream", 503);
    return result;
  } finally { await reader.cancel().catch(() => undefined); reader.releaseLock(); }
}
