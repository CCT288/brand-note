import { z } from "zod";
import { accessToken } from "./oauth";
import { completedOutput } from "./stream";
import { RESOURCE, ConnectionError } from "./contracts";
import { writeRecord } from "./storage";

const modelsSchema = z.object({ models: z.array(z.object({ slug: z.string(), display_name: z.string(), visibility: z.string().optional() })) });
export const verificationSchema = z.object({ checkedAt: z.string(), model: z.string(), text: z.boolean(), structured: z.boolean(), image: z.boolean(), sample: z.string(), observed: z.array(z.string()).default([]) });
const outputSchema = z.object({ summary: z.string().min(1), observed: z.array(z.string()) });
export async function listModels() {
  const response = await fetch(`${RESOURCE}/models`, { headers: { Authorization: `Bearer ${await accessToken()}` }, signal: AbortSignal.timeout(20_000), cache: "no-store" });
  if (!response.ok) throw new ConnectionError("未能读取此账号的可用模型。", `models_http_${response.status}`, 503);
  return modelsSchema.parse(await response.json()).models.filter(model => model.visibility === "list").map(({ slug, display_name }) => ({ slug, display_name }));
}
export async function verifyConnection(model: string, image?: string) {
  const models = await listModels();
  if (!models.some(option => option.slug === model)) throw new ConnectionError("请选择当前账号提供的模型。", "model_unavailable");
  const content: Array<Record<string, unknown>> = [{ type: "input_text", text: image ? "请用中文简短描述图片中可直接观察到的对象或行为，不要猜测品牌、身份或事件。" : "请用中文写一句自然简短的话，表达一个品牌正在和大家正式见面，但不要使用广告套话。observed 返回空数组。" }];
  if (image) content.push({ type: "input_image", image_url: image });
  const response = await fetch(`${RESOURCE}/responses`, { method: "POST", headers: { Authorization: `Bearer ${await accessToken()}`, "Content-Type": "application/json" }, body: JSON.stringify({ model, instructions: "这是连接能力验证。只返回满足 schema 的 JSON，不调用任何工具。", input: [{ role: "user", content }], store: false, stream: true, reasoning: { effort: "low" }, text: { format: { type: "json_schema", name: "connection_probe", strict: true, schema: z.toJSONSchema(outputSchema, { target: "draft-7" }) } } }), signal: AbortSignal.timeout(50_000) });
  const output = outputSchema.parse(JSON.parse(await completedOutput(response)));
  if (!/[\u3400-\u9fff]/.test(output.summary)) throw new ConnectionError("收到结果，但中文输出验证未通过。", "chinese_output_failed");
  if (image && output.observed.length === 0) throw new ConnectionError("收到结果，但图片观察验证未通过。", "image_output_failed");
  const report = { checkedAt: new Date().toISOString(), model, text: true, structured: true, image: !!image, sample: output.summary, observed: output.observed };
  await writeRecord("verification.json", report);
  return report;
}
