import { ConnectionError } from "./contracts";

export function requireLocalRequest(request: Request, mutation = false) {
  const url = new URL(request.url);
  const host = request.headers.get("host");
  if (process.env.NETLIFY || !["127.0.0.1", "localhost"].includes(url.hostname) || !["127.0.0.1:3010", "localhost:3010"].includes(host ?? "")) throw new ConnectionError("此授权入口仅供本机验证，尚未启用在线部署。", "local_only", 403);
  const origin = `${url.protocol}//${host}`;
  if (mutation && request.headers.get("origin") !== origin) throw new ConnectionError("请求来源不匹配。", "invalid_origin", 403);
  return origin;
}
export function errorResponse(error: unknown) {
  const typed = error instanceof ConnectionError ? error : new ConnectionError("连接请求未完成，请稍后重试。", "connection_failed", 503);
  return Response.json({ error: typed.message, code: typed.code }, { status: typed.status, headers: { "Cache-Control": "no-store" } });
}
