import { createRemoteJWKSet, jwtVerify } from "jose";
import { z } from "zod";
import { credentialSchema, pendingSchema, tokenSchema, PLAN_SCOPE, RESOURCE, ConnectionError, type Credentials, prepareAuthorization, validateCallback, publicConnection } from "./contracts";
import { hostId, readRecord, writeRecord, removeRecord, withConnectionLock } from "./storage";

const jwks = createRemoteJWKSet(new URL("https://auth.openai.com/.well-known/jwks.json"));
const registrationSchema = z.object({ client_id: z.string(), subject: z.string().optional() });
export const connectionStatus = async () => publicConnection(await readRecord("credentials.json", credentialSchema));
async function exchange(parameters: Record<string, string>) {
  const response = await fetch("https://auth.openai.com/api/accounts/oauth/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ resource: RESOURCE, ...parameters }), signal: AbortSignal.timeout(30_000), cache: "no-store" });
  if (!response.ok) throw new ConnectionError("OpenAI 未完成授权交换，请重新连接。", `oauth_http_${response.status}`, response.status === 400 ? 400 : 503);
  return await response.json();
}
async function verifiedIdentity(idToken: string, clientId: string, nonce?: string) {
  const { payload } = await jwtVerify(idToken, jwks, { issuer: "https://auth.openai.com", audience: clientId, algorithms: ["RS256"] });
  if (!payload.sub || (nonce && payload.nonce !== nonce)) throw new ConnectionError("账号身份校验失败，未启用此连接。", "invalid_identity");
  return { subject: payload.sub, email: typeof payload.email === "string" ? payload.email : "" };
}
export async function beginAuthorization(origin: string) {
  return withConnectionLock(async () => {
    const registration = await readRecord("registration.json", registrationSchema);
    const prepared = prepareAuthorization(`${origin}/auth/callback`, await hostId(), registration ?? undefined);
    await writeRecord("pending.json", prepared.pending);
    return prepared.url;
  });
}
export async function completeAuthorization(params: URLSearchParams) {
  return withConnectionLock(async () => {
    const pending = await readRecord("pending.json", pendingSchema);
    if (!pending) throw new ConnectionError("未找到授权会话，请重新连接。", "missing_authorization");
    const { clientId, code } = validateCallback(params, pending);
    await writeRecord("registration.json", { client_id: clientId, subject: pending.subject });
    const tokens = tokenSchema.parse(await exchange({ grant_type: "authorization_code", client_id: clientId, code, code_verifier: pending.verifier, redirect_uri: pending.redirect_uri }));
    const identity = await verifiedIdentity(tokens.id_token, clientId, pending.nonce);
    if (pending.subject && identity.subject !== pending.subject) throw new ConnectionError("登录账号与已登记账号不匹配，旧连接已保留。", "account_mismatch");
    const credentials: Credentials = { ...tokens, ...identity, client_id: clientId, expires_at: Date.now() + tokens.expires_in * 1000 };
    await writeRecord("credentials.json", credentials);
    await writeRecord("registration.json", { client_id: clientId, subject: identity.subject });
    await removeRecord("pending.json");
    return publicConnection(credentials);
  });
}
export async function accessToken() {
  return withConnectionLock(async () => {
    let credentials = await readRecord("credentials.json", credentialSchema);
    if (!credentials || credentials.reauth_required) throw new ConnectionError("请先通过官方页面连接 ChatGPT。", "sign_in_required", 401);
    if (!credentials.scope.split(" ").includes(PLAN_SCOPE)) throw new ConnectionError("账号已登录，但尚未授权使用 ChatGPT 计划。", "plan_permission_missing", 403);
    if (credentials.expires_at <= Date.now() + 60_000) {
      const replacement = await exchange({ grant_type: "refresh_token", client_id: credentials.client_id, refresh_token: credentials.refresh_token });
      const refreshed = tokenSchema.parse({ ...replacement, refresh_token: replacement.refresh_token ?? credentials.refresh_token, id_token: replacement.id_token ?? credentials.id_token, scope: replacement.scope ?? credentials.scope });
      // Save rotation before a further network request can fail. Until verified, inference is disabled.
      credentials = { ...credentials, ...refreshed, expires_at: Date.now() + refreshed.expires_in * 1000, reauth_required: true };
      await writeRecord("credentials.json", credentials);
      if (replacement.id_token) {
        const identity = await verifiedIdentity(refreshed.id_token, credentials.client_id);
        if (identity.subject !== credentials.subject) throw new ConnectionError("刷新后的账号身份不匹配，请重新连接。", "account_mismatch", 401);
      }
      credentials.reauth_required = false;
      await writeRecord("credentials.json", credentials);
    }
    if (!credentials.scope.split(" ").includes(PLAN_SCOPE)) throw new ConnectionError("ChatGPT 计划授权已失效，请重新连接。", "plan_permission_missing", 403);
    return credentials.access_token;
  });
}
export async function disconnect() {
  return withConnectionLock(async () => {
    const credentials = await readRecord("credentials.json", credentialSchema);
    let revoked = !credentials;
    if (credentials) {
      try {
        const response = await fetch("https://auth.openai.com/api/accounts/oauth/revoke", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ token: credentials.refresh_token, token_type_hint: "refresh_token", client_id: credentials.client_id }), signal: AbortSignal.timeout(15_000) });
        revoked = response.ok;
      } catch { revoked = false; }
    }
    await removeRecord("credentials.json");
    await removeRecord("pending.json");
    await removeRecord("verification.json");
    return { revoked };
  });
}
