#!/bin/zsh
set -eu
cd "${0:A:h}"
if ! command -v node >/dev/null 2>&1; then
  runtime_node="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin"
  if [[ -x "$runtime_node/node" ]]; then
    export PATH="$runtime_node:$PATH"
  else
    print '未找到 Node.js。请安装 Node.js 22.12 或更新版本后重试。'
    read -r '?按回车关闭。'
    exit 1
  fi
fi
if command -v pnpm >/dev/null 2>&1; then
  runner=(pnpm)
else
  runtime_pnpm="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/pnpm"
  if [[ -x "$runtime_pnpm" ]]; then
    runner=("$runtime_pnpm")
  else
    print '未找到 pnpm。请先安装 pnpm 后重试。'
    read -r '?按回车关闭。'
    exit 1
  fi
fi
if [[ ! -d node_modules ]]; then
  "${runner[@]}" install --frozen-lockfile
fi
print '浏览器打开：http://127.0.0.1:3010/settings'
print '这是本机服务入口。线上使用请打开已部署的网站；按 Control+C 停止本机服务。'
"${runner[@]}" dev
