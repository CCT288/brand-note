-- Supabase may create this event-trigger function when automatic RLS is enabled.
-- Application users never need to call it through the Data API.
do $$
begin
  if to_regprocedure('public.rls_auto_enable()') is not null then
    revoke execute on function public.rls_auto_enable() from public, anon, authenticated;
  end if;
end
$$;
