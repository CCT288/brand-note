-- BRAND NOTE: eight content tables, single owner, private media and encrypted AI records.
create schema if not exists private;
create table private.workspace_owner (singleton boolean primary key default true check(singleton), user_id uuid not null unique references auth.users(id));
alter table private.workspace_owner enable row level security;
create function private.is_owner() returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from private.workspace_owner where user_id=(select auth.uid()));$$;
revoke all on function private.is_owner() from public,anon;
grant usage on schema private to authenticated,service_role;
grant execute on function private.is_owner() to authenticated,service_role;
grant all on private.workspace_owner to service_role;

create table public.brands (
 id uuid primary key, user_id uuid not null references auth.users(id), name text not null, english_name text not null default '', category text not null default '', city text not null default '', description text not null default '', keywords jsonb not null default '[]', default_style_json jsonb not null, data_json jsonb not null, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(id,user_id)
);
create table public.brand_facts (
 id uuid primary key, user_id uuid not null, brand_id uuid not null, category text not null check(category in('Basic','Products','People','Space','Events','Other')), name text not null, content text not null, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), foreign key(brand_id,user_id) references public.brands(id,user_id) on delete cascade
);
create table public.brand_voice (
 id uuid primary key default gen_random_uuid(), user_id uuid not null, brand_id uuid not null unique, personality text not null default '', writing_principles text not null default '', avoid_rules text not null default '', created_at timestamptz not null default now(), updated_at timestamptz not null default now(), foreign key(brand_id,user_id) references public.brands(id,user_id) on delete cascade
);
create table public.brand_memory (
 id uuid primary key, user_id uuid not null, brand_id uuid not null, type text not null default 'preference', preference_key text not null, content text not null, confidence double precision not null check(confidence between 0 and 1), source_count integer not null check(source_count>=3), source_ids jsonb not null check(jsonb_array_length(source_ids)>=3), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(brand_id,preference_key), foreign key(brand_id,user_id) references public.brands(id,user_id) on delete cascade
);
create table public.contents (
 id uuid primary key, user_id uuid not null, brand_id uuid not null, content_type text not null, mode text not null check(mode in('Quick','Pro')), raw_input text not null, topic text not null default '', message text not null default '', must_include text not null default '', avoid text not null default '', style_json jsonb not null, direction jsonb, brand_snapshot jsonb not null, progress_json jsonb not null default '{}', ai_title text not null default '', ai_copy text not null default '', final_title text not null default '', final_copy text not null default '', status text not null check(status in('Draft','Used','Published')), archived_at timestamptz, version integer not null default 0, data_json jsonb not null, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(id,user_id), unique(id,brand_id,user_id), foreign key(brand_id,user_id) references public.brands(id,user_id)
);
create table public.content_variants (
 id uuid primary key, user_id uuid not null, content_id uuid not null, direction_index integer not null, direction_label text not null, direction_description text not null, title text not null, copy text not null, selected boolean not null default false, created_at timestamptz not null default now(), foreign key(content_id,user_id) references public.contents(id,user_id) on delete cascade
);
create table public.feedback (
 id uuid primary key, user_id uuid not null, brand_id uuid not null, content_id uuid not null, variant_id uuid references public.content_variants(id), feedback_type text not null, feedback_text text not null default '', revision_json jsonb not null, applied boolean not null default false, created_at timestamptz not null default now(), foreign key(content_id,brand_id,user_id) references public.contents(id,brand_id,user_id) on delete cascade
);
create table public.assets (
 id uuid primary key, user_id uuid not null, brand_id uuid not null, content_id uuid, file_path text not null, type text not null, analysis_json jsonb, data_json jsonb not null, created_at timestamptz not null default now(), foreign key(brand_id,user_id) references public.brands(id,user_id), foreign key(content_id,brand_id,user_id) references public.contents(id,brand_id,user_id)
);
create index brands_owner_idx on public.brands(user_id);
create index facts_brand_idx on public.brand_facts(brand_id,user_id);
create index contents_history_idx on public.contents(user_id,brand_id,archived_at desc) where archived_at is not null;
create index contents_owner_idx on public.contents(user_id,updated_at desc);
create index variants_content_idx on public.content_variants(content_id,user_id);
create index feedback_content_idx on public.feedback(content_id,brand_id,user_id);
create index feedback_variant_idx on public.feedback(variant_id);
create index assets_brand_idx on public.assets(brand_id,user_id);
create index assets_content_idx on public.assets(content_id,brand_id,user_id);

-- Explicit grants are necessary on projects with automatic table exposure disabled.
do $$declare t text;begin foreach t in array array['brands','brand_facts','brand_voice','brand_memory','contents','content_variants','feedback','assets'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('revoke all on public.%I from anon',t);
 execute format('grant select,insert,update,delete on public.%I to authenticated',t);
 execute format('grant all on public.%I to service_role',t);
 execute format('create policy owner_access on public.%I for all to authenticated using ((select private.is_owner()) and user_id=(select auth.uid())) with check ((select private.is_owner()) and user_id=(select auth.uid()))',t);
end loop;end $$;

create function public.bn_save_brand(payload jsonb) returns void language plpgsql security invoker set search_path='' as $$
declare owner uuid:=auth.uid(); b uuid:=(payload->>'id')::uuid; f jsonb; m jsonb;
begin
 if not private.is_owner() then raise insufficient_privilege; end if;
 insert into public.brands(id,user_id,name,english_name,category,city,description,keywords,default_style_json,data_json)
 values(b,owner,payload->>'name',payload->>'english_name',payload->>'category',payload->>'city',payload->>'description',payload->'keywords',payload->'default_style_json',payload)
 on conflict(id) do update set name=excluded.name,english_name=excluded.english_name,category=excluded.category,city=excluded.city,description=excluded.description,keywords=excluded.keywords,default_style_json=excluded.default_style_json,data_json=excluded.data_json,updated_at=now();
 delete from public.brand_facts where brand_id=b and user_id=owner;
 for f in select * from jsonb_array_elements(payload->'facts') loop
 insert into public.brand_facts(id,user_id,brand_id,category,name,content) values((f->>'id')::uuid,owner,b,f->>'category',f->>'name',f->>'content');end loop;
 insert into public.brand_voice(user_id,brand_id,personality,writing_principles,avoid_rules) values(owner,b,payload->'voice'->>'personality',payload->'voice'->>'writing_principles',payload->'voice'->>'avoid_rules')
 on conflict(brand_id) do update set personality=excluded.personality,writing_principles=excluded.writing_principles,avoid_rules=excluded.avoid_rules,updated_at=now();
 delete from public.brand_memory where brand_id=b and user_id=owner;
 for m in select * from jsonb_array_elements(payload->'memory') loop
 insert into public.brand_memory(id,user_id,brand_id,preference_key,content,confidence,source_count,source_ids) values((m->>'id')::uuid,owner,b,m->>'key',m->>'content',(m->>'confidence')::float,(m->>'source_count')::int,m->'source_ids');end loop;
end;$$;
revoke all on function public.bn_save_brand(jsonb) from public,anon;
grant execute on function public.bn_save_brand(jsonb) to authenticated;

create function public.bn_preserve_original() returns trigger language plpgsql set search_path='' as $$begin
 if old.ai_title<>'' and (new.ai_title<>old.ai_title or new.ai_copy<>old.ai_copy) then raise exception 'AI original is immutable';end if;
 if jsonb_array_length(old.data_json->'variants')>0 and new.data_json->'variants'<>old.data_json->'variants' then raise exception 'AI variants are immutable';end if;
 if old.archived_at is not null and new.archived_at is distinct from old.archived_at then raise exception 'Archive time is immutable';end if;
 if new.user_id<>old.user_id or new.brand_id<>old.brand_id or new.brand_snapshot<>old.brand_snapshot then raise exception 'Ownership and snapshot are immutable';end if;
 return new;end;$$;
create trigger content_original_guard before update on public.contents for each row execute function public.bn_preserve_original();
create function public.bn_variant_original() returns trigger language plpgsql set search_path='' as $$begin
 if new.title<>old.title or new.copy<>old.copy or new.direction_description<>old.direction_description or new.direction_label<>old.direction_label or new.content_id<>old.content_id or new.user_id<>old.user_id then raise exception 'AI variant is immutable';end if;return new;end;$$;
create trigger variant_original_guard before update on public.content_variants for each row execute function public.bn_variant_original();

create function public.bn_save_content(payload jsonb,expected_version integer) returns void language plpgsql security invoker set search_path='' as $$
declare owner uuid:=auth.uid(); c uuid:=(payload->>'id')::uuid; b uuid:=(payload->'brief'->>'brand_id')::uuid; old_version integer; v jsonb; r jsonb; idx integer:=0;
begin
 if not private.is_owner() or payload->>'owner_id'<>owner::text then raise insufficient_privilege;end if;
 select version into old_version from public.contents where id=c and user_id=owner for update;
 if old_version is distinct from expected_version or (payload->>'version')::int<>coalesce(expected_version,-1)+1 then raise exception 'version_conflict' using errcode='40001';end if;
 insert into public.contents(id,user_id,brand_id,content_type,mode,raw_input,topic,message,must_include,avoid,style_json,brand_snapshot,progress_json,ai_title,ai_copy,final_title,final_copy,status,archived_at,version,data_json)
 values(c,owner,b,payload->'brief'->>'content_type',payload->'brief'->>'mode',payload->'brief'->>'raw_input',payload->'brief'->>'topic',payload->'brief'->>'message',payload->'brief'->>'must_include',payload->'brief'->>'avoid',payload->'brief'->'style_json',payload->'brand_snapshot',payload->'stage_results',payload->>'ai_title',payload->>'ai_copy',payload->>'final_title',payload->>'final_copy',payload->>'status',(payload->>'archived_at')::timestamptz,(payload->>'version')::int,payload)
 on conflict(id) do update set content_type=excluded.content_type,progress_json=excluded.progress_json,ai_title=excluded.ai_title,ai_copy=excluded.ai_copy,final_title=excluded.final_title,final_copy=excluded.final_copy,status=excluded.status,archived_at=excluded.archived_at,version=excluded.version,data_json=excluded.data_json,updated_at=now();
 for v in select * from jsonb_array_elements(payload->'variants') loop
 insert into public.content_variants(id,user_id,content_id,direction_index,direction_label,direction_description,title,copy,selected)
 values((v->>'id')::uuid,owner,c,idx,v->'direction'->>'label',v->'direction'->>'angle',v->>'title',v->>'copy',coalesce((v->>'id')=payload->>'selected_variant_id',false))
 on conflict(id) do update set selected=excluded.selected;idx:=idx+1;end loop;
 for r in select * from jsonb_array_elements(payload->'revisions') loop
 insert into public.feedback(id,user_id,brand_id,content_id,variant_id,feedback_type,feedback_text,revision_json,applied)
 values((r->>'id')::uuid,owner,b,c,(r->>'variant_id')::uuid,r->>'kind',coalesce(r->>'feedback',''),r,(r->>'applied')::boolean)
 on conflict(id) do update set applied=excluded.applied,revision_json=excluded.revision_json;end loop;
end;$$;
revoke all on function public.bn_save_content(jsonb,integer) from public,anon;
grant execute on function public.bn_save_content(jsonb,integer) to authenticated;

create table public.ai_records(host_id text not null,record_name text not null,ciphertext text not null,updated_at timestamptz not null default now(),primary key(host_id,record_name));
create table public.runtime_locks(lock_key text primary key,token uuid not null,expires_at timestamptz not null);
alter table public.ai_records enable row level security;
alter table public.runtime_locks enable row level security;
revoke all on public.ai_records,public.runtime_locks from public,anon,authenticated;
grant all on public.ai_records,public.runtime_locks to service_role;
create function public.bn_claim_lock(lock_key text,lock_token uuid) returns boolean language plpgsql security invoker set search_path='' as $$declare claimed text;begin
 insert into public.runtime_locks(lock_key,token,expires_at) values($1,$2,now()+interval '180 seconds') on conflict on constraint runtime_locks_pkey do update set token=excluded.token,expires_at=excluded.expires_at where public.runtime_locks.expires_at<now() returning public.runtime_locks.lock_key into claimed;
 return claimed is not null;end;$$;
create function public.bn_release_lock(lock_key text,lock_token uuid) returns void language sql security invoker set search_path='' as $$delete from public.runtime_locks where runtime_locks.lock_key=$1 and token=$2;$$;
revoke all on function public.bn_claim_lock(text,uuid),public.bn_release_lock(text,uuid) from public,anon,authenticated;
grant execute on function public.bn_claim_lock(text,uuid),public.bn_release_lock(text,uuid) to service_role;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('brand-assets','brand-assets',false,5000000,array['image/png','image/jpeg','image/webp']);
create policy brand_asset_read on storage.objects for select to authenticated using(bucket_id='brand-assets' and (select private.is_owner()) and (storage.foldername(storage.objects.name))[1]=(select auth.uid())::text);
create policy brand_asset_insert on storage.objects for insert to authenticated with check(bucket_id='brand-assets' and (select private.is_owner()) and (storage.foldername(storage.objects.name))[1]=(select auth.uid())::text and exists(select 1 from public.brands where id::text=(storage.foldername(storage.objects.name))[2] and user_id=(select auth.uid())));
-- No public registration or public bucket. Configure Auth allow-list in the project settings before deployment.
