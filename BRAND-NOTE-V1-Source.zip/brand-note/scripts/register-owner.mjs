import { createClient } from '@supabase/supabase-js';
import { appendFile } from 'node:fs/promises';
const db=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL,process.env.SUPABASE_SECRET_KEY,{auth:{persistSession:false}});
const {data,error}=await db.auth.admin.listUsers({page:1,perPage:10});
if(error||data.users.length!==1)throw new Error('Exactly one manually created application user is required.');
const user=data.users[0];
await appendFile('.runtime/cloud.env',`APP_OWNER_ID=${user.id}\n`,{mode:0o600});
await import('node:fs/promises').then(fs=>fs.writeFile('.runtime/owner.sql',`insert into private.workspace_owner(user_id) values('${user.id}'::uuid);\n`,{mode:0o600}));
console.log('唯一应用账号已验证，归属 SQL 已保存到私有配置。');
