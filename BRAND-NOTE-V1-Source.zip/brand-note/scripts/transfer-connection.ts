import { readFile, rename } from "node:fs/promises";
import { createClient } from "@supabase/supabase-js";
import { encryptRecord, decryptRecord } from "../lib/chatgpt/encryption";
import { credentialSchema } from "../lib/chatgpt/contracts";

// Run once while the local server is stopped. Never upload the local verification report.
const host = process.env.BRAND_NOTE_HOST_ID!;
const key = process.env.BRAND_NOTE_ENCRYPTION_KEY!;
if (!host?.startsWith("urn:uuid:") || !key) throw new Error("Cloud host and encryption key are required.");
const db = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SECRET_KEY!, { auth: { persistSession: false } });
for (const name of ["registration.json", "settings.json", "demo-brands.json", "credentials.json"]) {
  let value: unknown;
  try { value = JSON.parse(await readFile(`.runtime/${name}`, "utf8")); }
  catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT" && name === "settings.json") continue; throw error; }
  if (name === "credentials.json") value = { ...credentialSchema.parse(value), expires_at: 0 };
  const aad = `${host}/${name}`;
  const { error } = await db.from("ai_records").upsert({ host_id: host, record_name: name, ciphertext: encryptRecord(value, key, aad), updated_at: new Date().toISOString() });
  if (error) throw new Error("Encrypted cloud record could not be saved.");
  const { data, error: checkError } = await db.from("ai_records").select("ciphertext").eq("host_id", host).eq("record_name", name).single();
  if (checkError || JSON.stringify(decryptRecord(data.ciphertext, key, aad)) !== JSON.stringify(value)) throw new Error("Encrypted cloud record verification failed.");
}
await rename(".runtime/credentials.json", ".runtime/credentials.transferred.json");
console.log("授权已加密转移并回读验证；本机停止使用此连接，云端首次调用将验证真实刷新。没有复制本机验收报告。");
