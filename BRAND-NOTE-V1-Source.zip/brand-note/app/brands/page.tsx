import { BrandsWorkspace } from "@/components/brands-workspace";
export default function BrandsPage(){return <BrandsWorkspace/>;}
