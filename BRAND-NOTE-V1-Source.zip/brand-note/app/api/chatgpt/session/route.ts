import { connectionStatus } from "@/lib/chatgpt/oauth";
import { readRecord } from "@/lib/chatgpt/storage";
import { verificationSchema } from "@/lib/chatgpt/probe";
import { authorize, errorResponse } from "@/lib/access";
export const runtime = "nodejs";
export async function GET(request: Request) {
  try { await authorize(request); return Response.json({ ...await connectionStatus(), verification: await readRecord("verification.json", verificationSchema) }, { headers: { "Cache-Control": "no-store" } }); }
  catch (error) { return errorResponse(error); }
}
