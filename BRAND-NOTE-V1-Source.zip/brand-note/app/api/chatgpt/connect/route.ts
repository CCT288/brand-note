import { beginAuthorization } from "@/lib/chatgpt/oauth";
import { requireLocalRequest, errorResponse } from "@/lib/chatgpt/local-access";
export const runtime = "nodejs";
export async function POST(request: Request) {
  try { requireLocalRequest(request, true); return Response.redirect(await beginAuthorization("http://127.0.0.1:3010"), 303); }
  catch (error) { return errorResponse(error); }
}
