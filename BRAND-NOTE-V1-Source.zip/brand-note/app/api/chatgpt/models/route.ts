import { listModels } from "@/lib/chatgpt/probe";
import { authorize, errorResponse } from "@/lib/access";
export const runtime = "nodejs";
export async function GET(request: Request) {
  try { await authorize(request); return Response.json({ models: await listModels() }, { headers: { "Cache-Control": "no-store" } }); }
  catch (error) { return errorResponse(error); }
}
