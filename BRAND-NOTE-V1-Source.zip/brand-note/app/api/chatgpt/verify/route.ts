import { z } from "zod";
import { verifyConnection } from "@/lib/chatgpt/probe";
import { authorize, errorResponse } from "@/lib/access";
export const runtime = "nodejs";
export async function POST(request: Request) {
  try {
    await authorize(request, true);
    const body = z.object({ model: z.string().min(1).max(200), image: z.string().max(8_000_000).regex(/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/).optional() }).parse(await request.json());
    return Response.json(await verifyConnection(body.model, body.image), { headers: { "Cache-Control": "no-store" } });
  } catch (error) { return errorResponse(error); }
}
