import { disconnect } from "@/lib/chatgpt/oauth";
import { authorize, errorResponse } from "@/lib/access";
export const runtime = "nodejs";
export async function POST(request: Request) {
  try { await authorize(request, true); return Response.json(await disconnect()); }
  catch (error) { return errorResponse(error); }
}
