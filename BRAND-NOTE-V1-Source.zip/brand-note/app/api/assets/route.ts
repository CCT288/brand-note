import { z } from "zod";
import { authorize,errorResponse,json } from "@/lib/access";
import { getBrand } from "@/lib/repository";
import { uploadAsset } from "@/lib/assets";
import { ConnectionError } from "@/lib/chatgpt/contracts";
export async function POST(request:Request) {
  try { const owner=await authorize(request,true); const data=await request.formData(); const brandId=z.string().uuid().parse(data.get("brand_id")); await getBrand(brandId); const file=data.get("file"); if(!(file instanceof File)) throw new ConnectionError("请选择图片。","file_missing"); return json(await uploadAsset(file,brandId,owner),201); } catch(error) {return errorResponse(error);}
}
