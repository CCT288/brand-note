import { authorize,errorResponse } from "@/lib/access";
import { listAssets } from "@/lib/repository";
import { assetBytes } from "@/lib/assets";
import { configured,userClient } from "@/lib/supabase/server";
import { ConnectionError } from "@/lib/chatgpt/contracts";
export async function GET(request:Request,context:{params:Promise<{id:string}>}) {
  try { await authorize(request); const {id}=await context.params; const asset=(await listAssets()).find(a=>a.id===id); if(!asset) throw new ConnectionError("素材不存在。","asset_not_found",404);
    if(configured()) { const db=await userClient(); const {data,error}=await db.storage.from("brand-assets").createSignedUrl(asset.path,60); if(error || !data) throw new ConnectionError("素材暂时无法访问。","asset_unavailable",503); return new Response(null,{status:307,headers:{Location:data.signedUrl,"Cache-Control":"no-store","Referrer-Policy":"no-referrer"}}); }
    return new Response(new Uint8Array(await assetBytes(asset)),{headers:{"Content-Type":asset.type,"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff"}});
  } catch(error) {return errorResponse(error);}
}
