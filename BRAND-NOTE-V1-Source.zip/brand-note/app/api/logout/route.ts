import { authorize,errorResponse } from "@/lib/access";
import { userClient } from "@/lib/supabase/server";
export async function POST(request:Request){try{await authorize(request,true);const db=await userClient();await db.auth.signOut();return Response.redirect(`${process.env.APP_URL}/login`,303);}catch(error){return errorResponse(error);}}
