import { randomUUID } from "node:crypto";
import { authorize,errorResponse,json } from "@/lib/access";
import { editSchema,publicContent } from "@/lib/ai/pipeline";
import { getContent,saveContent,updateMemory } from "@/lib/repository";
import { ConnectionError } from "@/lib/chatgpt/contracts";
type Params = { params:Promise<{id:string}> };
export async function GET(request:Request,context:Params) { try { const owner=await authorize(request); const {id}=await context.params; return json(publicContent(await getContent(id,owner))); } catch(error) {return errorResponse(error);} }
export async function PATCH(request:Request,context:Params) {
  try {
    const owner=await authorize(request,true); const {id}=await context.params; const item=await getContent(id,owner); const edit=editSchema.parse(await request.json());
    const original=item.variants.find(v=>v.id===edit.variant_id); if(!original) throw new ConnectionError("找不到这个方向。","variant_not_found",404);
    if(edit.expected_version!==item.version) throw new ConnectionError("已有新的修改，请重新读取后保存。","version_conflict",409);
    if(!item.ai_title) {item.ai_title=original.title; item.ai_copy=original.copy;}
    item.selected_variant_id=original.id; item.final_title=edit.title; item.final_copy=edit.copy; item.status=edit.status;
    item.revisions.push({id:randomUUID(),variant_id:original.id,kind:"manual",title:edit.title,copy:edit.copy,applied:true,created_at:new Date().toISOString()});
    if(edit.applied_revision_id) { const revision=item.revisions.find(r=>r.id===edit.applied_revision_id && r.variant_id===original.id); if(!revision) throw new ConnectionError("建议不存在。","revision_not_found"); revision.applied=true; }
    if(edit.archive) item.archived_at ??= new Date().toISOString();
    const saved=await saveContent(item,item.version);
    if(saved.archived_at) await updateMemory(item.brief.brand_id,owner);
    return json(publicContent(saved));
  } catch(error) {return errorResponse(error);}
}
