import { authorize,errorResponse,json } from "@/lib/access";
import { advanceGeneration,publicContent } from "@/lib/ai/pipeline";
import { withFileLock } from "@/lib/chatgpt/storage";
export const runtime="nodejs";
export const maxDuration=60;
export async function POST(request:Request,context:{params:Promise<{id:string}>}) { try { const owner=await authorize(request,true); const {id}=await context.params; return json(await withFileLock(`generation-${id}`,async()=>publicContent(await advanceGeneration(id,owner)))); } catch(error) {return errorResponse(error);} }
