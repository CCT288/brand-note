import { authorize,errorResponse,json } from "@/lib/access";
import { rewrite,rewriteRequest } from "@/lib/ai/rewrite";
import { withFileLock } from "@/lib/chatgpt/storage";
export const maxDuration=60;
export async function POST(request:Request,context:{params:Promise<{id:string}>}) { try { const owner=await authorize(request,true); const {id}=await context.params; const body=rewriteRequest.parse(await request.json()); return json(await withFileLock(`generation-${id}`,()=>rewrite(id,owner,body))); } catch(error) {return errorResponse(error);} }
