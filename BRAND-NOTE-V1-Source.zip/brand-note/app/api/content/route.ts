import { authorize,errorResponse,json } from "@/lib/access";
import { briefSchema } from "@/lib/domain";
import { createGeneration,publicContent } from "@/lib/ai/pipeline";
import { readRecord } from "@/lib/chatgpt/storage";
import { verificationSchema,listModels } from "@/lib/chatgpt/probe";
import { ConnectionError } from "@/lib/chatgpt/contracts";
export async function POST(request:Request) {
  try {
    const owner = await authorize(request,true);
    const verified = await readRecord("verification.json",verificationSchema);
    if (!verified?.image || !verified.text || !verified.structured) throw new ConnectionError("请先在设置中 完成真实文本和图片验证。","connection_not_verified",403);
    const body = briefSchema.parse(await request.json());
    const item = await createGeneration(owner,body);
    const models = await listModels();
    if (![item.model,item.vision_model].every(model => models.some(m => m.slug === model))) throw new ConnectionError("选定模型当前不可用，请在设置中 重新选择。","model_unavailable",403);
    return json(publicContent(item),201);
  } catch(error) {return errorResponse(error);}
}
