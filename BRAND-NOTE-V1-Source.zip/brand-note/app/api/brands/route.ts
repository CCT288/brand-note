import { brandSchema } from "@/lib/domain";
import { authorize,errorResponse,json } from "@/lib/access";
import { saveBrand,listBrands } from "@/lib/repository";
export async function POST(request: Request) {
  try { await authorize(request,true); const brand = brandSchema.parse(await request.json()); const old = (await listBrands()).find(b=>b.id === brand.id); return json(await saveBrand({...brand,memory:old?.memory ?? []})); } catch(error) {return errorResponse(error);}
}
