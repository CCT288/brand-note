import { authorize,errorResponse,json } from "@/lib/access";
import { settingsSchema } from "@/lib/domain";
import { readRecord,writeRecord } from "@/lib/chatgpt/storage";
import { listModels } from "@/lib/chatgpt/probe";
import { ConnectionError } from "@/lib/chatgpt/contracts";
import { configured,cloudMode } from "@/lib/supabase/server";
export async function GET(request:Request){try{await authorize(request);return json({settings:await readRecord("settings.json",settingsSchema)??settingsSchema.parse({}),database:configured(),deployment:cloudMode()?"cloud":"local"});}catch(error){return errorResponse(error);}}
export async function POST(request:Request){try{await authorize(request,true);const value=settingsSchema.parse(await request.json());const models=await listModels();if(![value.text_model,value.vision_model].every(slug=>models.some(m=>m.slug===slug)))throw new ConnectionError("请选择此账号可用的模型。","model_unavailable");await writeRecord("settings.json",value);return json(value);}catch(error){return errorResponse(error);}}
