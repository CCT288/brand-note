import { authorize,errorResponse,json } from "@/lib/access";
import { initializeBrands,listBrands,listContents } from "@/lib/repository";
import { publicContent } from "@/lib/ai/pipeline";
import { configured } from "@/lib/supabase/server";
export const runtime = "nodejs";
export async function GET(request: Request) {
  try { const owner = await authorize(request); return json({ brands:await listBrands(),contents:(await listContents(owner)).map(publicContent),cloud:configured() }); } catch(error) { return errorResponse(error); }
}
export async function POST(request: Request) { try { await authorize(request,true); await initializeBrands(); return json({ok:true}); } catch(error) {return errorResponse(error);} }
