import type { Metadata } from "next";
import { AppShell } from "@/components/layout/app-shell";
import "./globals.css";

export const metadata: Metadata = { title: "BRAND NOTE", description: "先理解品牌，再理解这次内容，最后才开始写。" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="zh-CN"><body><AppShell>{children}</AppShell></body></html>;
}
