import { completeAuthorization } from "@/lib/chatgpt/oauth";
import { requireLocalRequest, errorResponse } from "@/lib/chatgpt/local-access";
import { ConnectionError } from "@/lib/chatgpt/contracts";
export const runtime = "nodejs";
export async function GET(request: Request) {
  let origin: string;
  try { origin = requireLocalRequest(request); } catch (error) { return errorResponse(error); }
  const destination = new URL("/settings", origin);
  try {
    await completeAuthorization(new URL(request.url).searchParams);
    destination.searchParams.set("connection", "success");
  } catch (error) {
    destination.searchParams.set("connection", "failed");
    destination.searchParams.set("code", error instanceof ConnectionError ? error.code : "identity_verification_failed");
  }
  return new Response(null, { status: 303, headers: { Location: destination.toString(), "Cache-Control": "no-store", "Referrer-Policy": "no-referrer" } });
}
