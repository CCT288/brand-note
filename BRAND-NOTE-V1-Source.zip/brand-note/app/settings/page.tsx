import { ConnectionPanel } from "@/components/settings/connection-panel";
export default function SettingsPage() {
  return <><h1 className="text-3xl font-medium tracking-tight">设置</h1><p className="mt-2 text-sm text-muted-foreground">连接一次，之后专心写作。</p><ConnectionPanel/></>;
}
