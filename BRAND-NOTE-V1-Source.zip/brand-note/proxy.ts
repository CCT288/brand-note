import { createServerClient } from "@supabase/ssr";
import { NextResponse,type NextRequest } from "next/server";
export async function proxy(request:NextRequest){
  const deployed=process.env.APP_DEPLOYMENT==="cloud"||!!process.env.NETLIFY;
  if(!deployed)return NextResponse.next();
  const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,owner=process.env.APP_OWNER_ID;
  if(!url||!key||!owner)return new NextResponse("工作台正在配置，尚未开放。",{status:503,headers:{"Cache-Control":"no-store"}});
  let response=NextResponse.next({request});
  const db=createServerClient(url,key,{cookies:{getAll:()=>request.cookies.getAll(),setAll:values=>{values.forEach(({name,value})=>request.cookies.set(name,value));response=NextResponse.next({request});values.forEach(({name,value,options})=>response.cookies.set(name,value,options));}}});
  const {data,error}=await db.auth.getClaims();
  if((error||data?.claims.sub!==owner)&&!request.nextUrl.pathname.startsWith("/login")&&!request.nextUrl.pathname.startsWith("/api/login")){
    const denied=request.nextUrl.pathname.startsWith("/api/")?NextResponse.json({error:"请使用指定账号登录。",code:"unauthorized"},{status:401}):NextResponse.redirect(new URL("/login",request.url));
    response.cookies.getAll().forEach(cookie=>denied.cookies.set(cookie));denied.headers.set("Cache-Control","no-store");return denied;
  }
  response.headers.set("Cache-Control","private, no-store");return response;
}
export const config={matcher:["/((?!_next/static|_next/image|favicon.ico).*)"]};
